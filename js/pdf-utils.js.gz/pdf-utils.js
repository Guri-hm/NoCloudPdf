let pdfConfig = null;

// ========================================
// 共通ユーティリティ関数
// ========================================

/**
 * Base64文字列をUint8Arrayに変換
 */
function base64ToUint8Array(base64) {
    const cleanBase64 = base64.replace(/[\r\n\s]/g, "");
    const binaryString = atob(cleanBase64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

/**
 * データ型の統一変換関数
 */
function toUint8Array(data) {
    if (data instanceof Uint8Array) {
        return data;
    } else if (Array.isArray(data)) {
        return new Uint8Array(data);
    } else if (typeof data === 'string') {
        return base64ToUint8Array(data);
    } else {
        return new Uint8Array(data);
    }
}

/**
 * Uint8Array → Base64 変換ヘルパー
 */
function uint8ArrayToBase64(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

/**
 * PDF.js 読み込みヘルパー
 */
async function loadPdfDocument(uint8Array, options = {}) {
    const pdfjsLib = window.pdfjsLib;
    if (!pdfjsLib) throw new Error('PDF.js library not loaded');

    const defaultOptions = {
        data: uint8Array,
        cMapUrl: pdfjsLib.GlobalWorkerOptions.cMapUrl,
        cMapPacked: pdfjsLib.GlobalWorkerOptions.cMapPacked,
        standardFontDataUrl: pdfjsLib.GlobalWorkerOptions.standardFontDataUrl,
        wasmUrl: pdfjsLib.GlobalWorkerOptions.wasmUrl,
        openjpegJsUrl: pdfjsLib.GlobalWorkerOptions.openjpegJsUrl,
        verbosity: 0,
    };

    const loadingTask = pdfjsLib.getDocument({ ...defaultOptions, ...options });
    return await loadingTask.promise;
}

/**
 * Canvas レンダリングヘルパー
 */
async function renderPageToCanvas(page, scale, rotation = 0, options = {}) {
    const viewport = page.getViewport({ scale, rotation });

    // QR読み取り用に高解像度を許可（最大4096px、デフォルトは2048だったが制限を緩和）
    const maxDimension = options.maxDimension || 4096;
    let width = Math.round(viewport.width);
    let height = Math.round(viewport.height);

    if (width > maxDimension || height > maxDimension) {
        const adjustedScale = Math.min(maxDimension / width, maxDimension / height);
        width = Math.round(width * adjustedScale);
        height = Math.round(height * adjustedScale);
    }

    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, width);
    canvas.height = Math.max(1, height);

    const context = canvas.getContext('2d', { alpha: false, willReadFrequently: false });

    if (options.fillWhite) {
        context.fillStyle = '#FFFFFF';
        context.fillRect(0, 0, canvas.width, canvas.height);
    }

    const renderContext = {
        canvasContext: context,
        viewport: page.getViewport({ scale: scale * (width / viewport.width), rotation }),
        intent: 'display'
    };

    await page.render(renderContext).promise;

    return canvas;
}


/**
 * RGB ヘルパー（Hex → RGB）
 */
function hexToRgb(hex) {
    const { rgb } = PDFLib;
    hex = hex.replace('#', '');
    if (hex.length === 3) {
        hex = hex.split('').map(x => x + x).join('');
    }
    const num = parseInt(hex, 16);
    return rgb(
        ((num >> 16) & 255) / 255,
        ((num >> 8) & 255) / 255,
        (num & 255) / 255
    );
}

/**
 * 回転角度を0/90/180/270に正規化
 */
function normalizeRotationAngle(rotateAngle) {
    const angle = ((Number(rotateAngle) || 0) % 360 + 360) % 360;
    return (Math.round(angle / 90) * 90) % 360;
}

/**
 * 共通エラーハンドラー
 */
function handlePdfError(error, context) {
    console.error(`${context} error:`, error);

    if (error && error.name === "PasswordException") {
        return {
            thumbnail: "",
            isPasswordProtected: true,
            securityInfo: "パスワード付きPDF"
        };
    }

    return {
        thumbnail: "",
        isError: true,
        securityInfo: "解析失敗"
    };
}

/**
 * 日本語判定
 * \u3000-\u30FF: ひらがな・カタカナ（全角のみ）
 * \u4E00-\u9FFF: 漢字
 * \uFF01-\uFF9F: 半角記号・英数字・半角カタカナ
 */
function containsJapanese(text) {
    return /[\u3000-\u30FF\u4E00-\u9FFF\uFF01-\uFF9F]/.test(text || "");
}
// ========================================
// フォント管理クラス
// ========================================
class PdfFontManager {
    constructor(pdfDoc) {
        this.pdfDoc = pdfDoc;
        this.cache = {};
    }

    async getFont(text, options = {}) {
        const { isBold = false, isSerif = false } = options;
        const isJapanese = containsJapanese(text);

        if (isJapanese) {
            const fontKey = isSerif
                ? (isBold ? 'notoSerifBold' : 'notoSerifReg')
                : (isBold ? 'notoSansBold' : 'notoSansReg');

            if (!this.cache[fontKey]) {
                const fontMap = {
                    notoSerifBold: '/fonts/NotoSerifJP-Bold.ttf',
                    notoSerifReg: '/fonts/NotoSerifJP-Regular.ttf',
                    notoSansBold: '/fonts/NotoSansJP-Bold.ttf',
                    notoSansReg: '/fonts/NotoSansJP-Regular.ttf'
                };
                const bytes = await fetch(fontMap[fontKey]).then(r => r.arrayBuffer());
                this.cache[fontKey] = await this.pdfDoc.embedFont(bytes);
            }
            return this.cache[fontKey];
        } else {
            const { StandardFonts } = PDFLib;
            return isBold
                ? await this.pdfDoc.embedFont(StandardFonts.HelveticaBold)
                : await this.pdfDoc.embedFont(StandardFonts.Helvetica);
        }
    }
}

// ========================================
// キャッシュマネージャークラス
// ========================================
class PdfCacheManager {
    constructor() {
        this.libCache = new Map();
        this.restrictedFiles = new Set();
        this.renderingFlags = {};
    }

    set(key, doc) { this.libCache.set(key, doc); }
    get(key) { return this.libCache.get(key); }
    has(key) { return this.libCache.has(key); }
    delete(key) {
        this.libCache.delete(key);
        this.restrictedFiles.delete(key);
    }
    clear() {
        this.libCache.clear();
        this.restrictedFiles.clear();
    }

    markRestricted(key) { this.restrictedFiles.add(key); }
    isRestricted(key) { return this.restrictedFiles.has(key); }
    clearRestricted() { this.restrictedFiles.clear(); }

    setRendering(key, value) { this.renderingFlags[key] = value; }
    isRendering(key) { return !!this.renderingFlags[key]; }
}

window._pdfCache = new PdfCacheManager();

// ========================================
// PDF ページストレージマネージャークラス
// ========================================
class PdfPageStorageManager {
    constructor() {
        this.storage = new Map(); // Key: "{fileId}_{pageIndex}" → Value: Uint8Array
        this.metadata = new Map(); // Key: "{fileId}_{pageIndex}" → Value: { size, timestamp }
    }

    set(fileId, pageIndex, uint8Array) {
        const key = `${fileId}_${pageIndex}`;
        this.storage.set(key, uint8Array);
        this.metadata.set(key, {
            size: uint8Array.byteLength,
            timestamp: Date.now()
        });
    }

    get(fileId, pageIndex) {
        const key = `${fileId}_${pageIndex}`;
        return this.storage.get(key);
    }

    has(fileId, pageIndex) {
        const key = `${fileId}_${pageIndex}`;
        return this.storage.has(key);
    }

    delete(fileId, pageIndex) {
        const key = `${fileId}_${pageIndex}`;
        this.storage.delete(key);
        this.metadata.delete(key);
    }

    deleteAllForFile(fileId) {
        let count = 0;
        for (const key of Array.from(this.storage.keys())) {
            if (key.startsWith(`${fileId}_`)) {
                this.storage.delete(key);
                this.metadata.delete(key);
                count++;
            }
        }
        return count;
    }

    clear() {
        this.storage.clear();
        this.metadata.clear();
    }

    getTotalSize() {
        let total = 0;
        for (const meta of this.metadata.values()) {
            total += meta.size;
        }
        return total;
    }

    getStorageInfo() {
        return {
            pageCount: this.storage.size,
            totalSizeBytes: this.getTotalSize(),
            totalSizeMB: (this.getTotalSize() / 1024 / 1024).toFixed(2)
        };
    }
}

window._pdfPageStorage = new PdfPageStorageManager();

// 後方互換性のためのエイリアス
window._pdfLibCache = window._pdfCache.libCache;
window._pdfLibFileRestricted = window._pdfCache.restrictedFiles;
window._canvasRendering = window._pdfCache.renderingFlags;

window._pdfLibFileIsRestricted = function (key) {
    return window._pdfCache.isRestricted(key);
};

window._pdfLibCacheClear = function () {
    window._pdfCache.clear();
    return true;
};

window._pdfLibCacheDelete = function (key) {
    if (!key) return false;
    window._pdfCache.delete(key);
    return true;
};

window._pdfLibFileRestrictedClear = function () {
    window._pdfCache.clearRestricted();
    return true;
};

// ========================================
// 設定読み込み
// ========================================
window.loadConfig = async function () {
    if (!pdfConfig) {
        const response = await fetch('/config.json');
        pdfConfig = await response.json();
    }
    return pdfConfig;
};
window.loadConfig();

// ========================================
// 画像 → PDF 変換
// ========================================
window.embedImageAsPdf = async function (imageBase64, ext) {
    const { PDFDocument } = PDFLib;
    const pdfDoc = await PDFDocument.create();
    let img;
    const bytes = base64ToUint8Array(imageBase64);

    if (ext.endsWith('.png')) {
        img = await pdfDoc.embedPng(bytes);
    } else if (ext.endsWith('.jpg') || ext.endsWith('.jpeg')) {
        img = await pdfDoc.embedJpg(bytes);
    } else if (
        ext.endsWith('.gif') ||
        ext.endsWith('.bmp') ||
        ext.endsWith('.webp') ||
        ext.endsWith('.svg')
    ) {
        const mime = ext.endsWith('.gif') ? 'image/gif'
            : ext.endsWith('.bmp') ? 'image/bmp'
                : ext.endsWith('.webp') ? 'image/webp'
                    : ext.endsWith('.svg') ? 'image/svg+xml'
                        : '';
        const { pngBase64 } = await window.convertImageToPngBase64AndSize(imageBase64, mime);
        img = await pdfDoc.embedPng(base64ToUint8Array(pngBase64.split(',')[1]));
    } else {
        throw new Error('Unsupported image type');
    }

    const imgDims = img.scale(1);
    const page = pdfDoc.addPage([imgDims.width, imgDims.height]);
    page.drawImage(img, { x: 0, y: 0, width: imgDims.width, height: imgDims.height });
    const pdfBytes = await pdfDoc.save();

    return uint8ArrayToBase64(pdfBytes);
};

// ========================================
// PDF結合
// ========================================
window.mergePDFPages = async function (pdfPageDataList) {
    const { PDFDocument, degrees } = PDFLib;
    const mergedPdf = await PDFDocument.create();

    for (let i = 0; i < pdfPageDataList.length; i++) {
        let pageInfo = pdfPageDataList[i];
        let pageData = pageInfo.pageData;

        const bytes = toUint8Array(pageData);

        try {
            const pdfDoc = await PDFDocument.load(bytes);
            const [page] = await mergedPdf.copyPages(pdfDoc, [0]);

            if (typeof pageInfo === 'object' && pageInfo.rotateAngle && pageInfo.rotateAngle % 360 !== 0) {
                page.setRotation(degrees(pageInfo.rotateAngle));
            }

            mergedPdf.addPage(page);
        } catch (error) {
            console.error(`Error at mergePDFPages index=${i}:`, error);
            throw error;
        }
    }

    const mergedPdfBytes = await mergedPdf.save();
    const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
    return URL.createObjectURL(blob);
};

// ========================================
// PDF情報取得（サムネイル・ブックマーク等）
// ========================================
window.renderFirstPDFPage = async function (fileData, password) {
    try {
        const uint8Array = toUint8Array(fileData);

        if (uint8Array.length < 8) {
            throw new Error('Data too short to be valid PDF');
        }

        const header = String.fromCharCode.apply(null, uint8Array.slice(0, 8));
        if (!header.startsWith('%PDF-')) {
            throw new Error(`Invalid PDF header: ${header}`);
        }

        let pdf = null;
        let isPasswordProtected = false;
        let lastError = null;

        const loadingOptions = [
            {
                stopAtErrors: false,
                maxImageSize: -1,
                disableFontFace: true,
                disableRange: true,
                disableStream: true,
                verbosity: 0
            },
            {
                stopAtErrors: false,
                maxImageSize: -1, // 埋め込み画像の最大サイズ制限なし
                disableFontFace: false,
                disableRange: true,
                disableStream: false,
                verbosity: 0
            },
            {
                stopAtErrors: false,
                maxImageSize: -1,
                verbosity: 0
            }
        ];

        for (let i = 0; i < loadingOptions.length; i++) {
            try {
                pdf = await loadPdfDocument(uint8Array, { ...loadingOptions[i], password: password || undefined });
                break;
            } catch (error) {
                lastError = error;
                if (error && error.name === "PasswordException") {
                    isPasswordProtected = true;
                    break;
                }
                if (i === loadingOptions.length - 1) {
                    throw lastError;
                }
            }
        }

        if (isPasswordProtected || !pdf) {
            return {
                thumbnail: "",
                isPasswordProtected: true,
                securityInfo: "パスワード付きPDF"
            };
        }

        const page = await pdf.getPage(1);

        let pageRotation = 0;
        try {
            if (typeof page.getRotation === 'function') pageRotation = page.getRotation();
            else if (typeof page.rotate !== 'undefined') pageRotation = page.rotate;
        } catch (e) {
            pageRotation = 0;
        }
        pageRotation = ((Number(pageRotation) || 0) % 360 + 360) % 360;

    const viewport = page.getViewport({ scale: 1.0, rotation: 0 });
    // サムネイル解像度を引き上げる（QR読み取り用に高解像度を生成）
    // ここは大きめにしておき、renderPageToCanvas側で maxDimension による調整を受ける
    const targetWidth = 800;
    const scale = targetWidth / viewport.width;

        let thumbnail = "";
        try {
            const renderPromise = renderPageToCanvas(page, scale, 0);
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Thumbnail rendering timeout')), 10000)
            );

            const canvas = await Promise.race([renderPromise, timeoutPromise]);
            thumbnail = await canvasToBlobUrl(canvas, 'image/jpeg', 0.8);
        } catch (renderError) {
            console.error('Thumbnail rendering failed:', renderError);
            try {
                const fallbackScale = targetWidth / 2 / viewport.width;
                const canvas = await renderPageToCanvas(page, fallbackScale, 0);
                const blobUrl = await canvasToBlobUrl(canvas, 'image/jpeg', 0.8);
                thumbnail = blobUrl;
            } catch (fallbackError) {
                console.error('Fallback thumbnail rendering also failed:', fallbackError);
                thumbnail = "";
            }
        }

        // ブックマーク取得
        let bookmarks = [];
        try {
            const outline = await pdf.getOutline();
            if (outline && outline.length) {
                async function mapOutlineItems(items) {
                    const results = [];
                    for (const it of items) {
                        let pageIndex = null;
                        try {
                            let dest = it.dest;
                            if (typeof dest === 'string') {
                                dest = await pdf.getDestination(dest);
                            }
                            if (Array.isArray(dest) && dest.length > 0) {
                                try { pageIndex = await pdf.getPageIndex(dest[0]); } catch (e) { pageIndex = null; }
                            }
                        } catch (e) { /* ignore */ }

                        const node = {
                            title: it.title || '',
                            pageIndex: pageIndex !== null ? pageIndex : -1,
                            items: []
                        };
                        if (it.items && it.items.length) {
                            node.items = await mapOutlineItems(it.items);
                        }
                        results.push(node);
                    }
                    return results;
                }
                bookmarks = await mapOutlineItems(outline);
            }
        } catch (e) {
            console.error('pdf: outline extraction failed', e);
        }

        return {
            thumbnail,
            isPasswordProtected: false,
            securityInfo: "",
            bookmarks,
            pageRotation
        };

    } catch (error) {
        console.error('renderFirstPDFPage error:', error);
        return handlePdfError(error, 'renderFirstPDFPage');
    }
};

// ========================================
// 指定ページのサムネイル生成
// ========================================
window.generatePdfThumbnailFromFileMetaData = async function (pdfFileData, pageIndex) {
    try {
        const uint8Array = toUint8Array(pdfFileData);
        const pdf = await loadPdfDocument(uint8Array);

        const page = await pdf.getPage(pageIndex + 1);
        
        // QRコード検出用に高解像度サムネイルを生成（renderFirstPDFPageと同じ解像度）
        const viewport = page.getViewport({ scale: 1.0, rotation: 0 });
        const targetWidth = 800; // QR読み取り用に高解像度
        const scale = targetWidth / viewport.width;
        
        const canvas = await renderPageToCanvas(page, scale, 0);
        const blobUrl = await canvasToBlobUrl(canvas, 'image/jpeg', 0.8);

        return {
            thumbnail: blobUrl,
            isError: false,
            isPasswordProtected: false,
            securityInfo: ""
        };
    } catch (error) {
        return handlePdfError(error, 'generatePdfThumbnailFromFileMetaData');
    }
};

/**
 * 指定ページの高解像度プレビュー画像を生成（QRコード検出＋表示用）
 * @param {Uint8Array|string} pdfFileData - PDFファイルデータ
 * @param {number} pageIndex - ページインデックス（0始まり）
 * @returns {Promise<string>} Blob URL
 */
window.generateHighResPagePreview = async function (pdfFileData, pageIndex) {
    try {
        const uint8Array = toUint8Array(pdfFileData);
        const pdf = await loadPdfDocument(uint8Array);

        const page = await pdf.getPage(pageIndex + 1);
        
        // 高解像度プレビュー生成（renderFirstPDFPageと同じ）
        const viewport = page.getViewport({ scale: 1.0, rotation: 0 });
        const targetWidth = 800; // QR読み取りに十分な解像度
        const scale = targetWidth / viewport.width;
        
        const canvas = await renderPageToCanvas(page, scale, 0);
        const blobUrl = await canvasToBlobUrl(canvas, 'image/jpeg', 0.8);

        return blobUrl;
    } catch (error) {
        console.error('generateHighResPagePreview error:', error);
        throw error;
    }
};

// ========================================
// 画像変換ヘルパー
// ========================================
window.convertImageToPngBase64AndSize = function (base64OrDataUrl, mime) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = function () {
            const canvas = document.createElement('canvas');
            canvas.width = img.width || 800;
            canvas.height = img.height || 600;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            const pngBase64 = canvas.toDataURL('image/png');
            resolve({ pngBase64, width: img.width, height: img.height });
        };
        img.onerror = reject;

        if (base64OrDataUrl.startsWith('data:')) {
            img.src = base64OrDataUrl;
        } else if (mime) {
            img.src = `data:${mime};base64,${base64OrDataUrl}`;
        } else {
            img.src = `data:image/png;base64,${base64OrDataUrl}`;
        }
    });
};

// ========================================
// PDFページ数取得
// ========================================
window.getPDFPageCount = async function (pdfData) {
    try {
        const uint8Array = toUint8Array(pdfData);
        const pdf = await loadPdfDocument(uint8Array, { stopAtErrors: false, verbosity: 1 });
        return pdf.numPages;
    } catch (error) {
        console.error('Error in getPDFPageCount:', error);
        throw error;
    }
};

// ========================================
// 画像フォールバック処理
// ========================================
async function imageFallbackPdf(uint8Array, pageIndex, cacheKey = null) {
    if (cacheKey) {
        window._pdfCache.markRestricted(cacheKey);
    }

    const pdf = await loadPdfDocument(uint8Array);
    const page = await pdf.getPage(pageIndex + 1);

    const scale = pdfConfig?.pdfSettings?.scales?.unlock || 1.5;
    const canvas = await renderPageToCanvas(page, scale, 0, { fillWhite: true });

    const imgDataUrl = canvas.toDataURL('image/png');
    const imgBytes = base64ToUint8Array(imgDataUrl.split(',')[1]);

    const { PDFDocument } = PDFLib;
    const imgPdf = await PDFDocument.create();
    const embedded = await imgPdf.embedPng(imgBytes);
    imgPdf.addPage([canvas.width, canvas.height]);
    const [imgPage] = imgPdf.getPages();
    imgPage.drawImage(embedded, { x: 0, y: 0, width: canvas.width, height: canvas.height });

    const newPdfBytes = await imgPdf.save();
    return uint8ArrayToBase64(newPdfBytes);
}

/**
 * 制限付きPDF専用：元PDFから直接トリミング領域を高解像度で切り出し
 */
window.cropRestrictedPdfPageToImage = async function (
    fileData,           // 元のFileData (byte[])
    pageIndex,          // ページ番号
    normX, normY, normWidth, normHeight,  // 正規化座標
    rotateAngle = 0,
    dpi = 300
) {
    try {
        const uint8Array = toUint8Array(fileData);
        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(pageIndex + 1);

        const originalViewport = page.getViewport({ scale: 1.0, rotation: 0 });
        const pageW = originalViewport.width;
        const pageH = originalViewport.height;

        const quant = normalizeRotationAngle(rotateAngle);
        const scale = dpi / 72;

        const nx = Math.max(0, Math.min(1, Number(normX) || 0));
        const ny = Math.max(0, Math.min(1, Number(normY) || 0));
        const nw = Math.max(0, Math.min(1, Number(normWidth) || 0));
        const nh = Math.max(0, Math.min(1, Number(normHeight) || 0));

        // トリミング範囲計算（cropPdfPageToImageと同じ）
        const llx = nx * pageW;
        const lly = pageH * (1 - ny - nh);
        const urx = llx + (nw * pageW);
        const ury = lly + (nh * pageH);

        // 高解像度で全体をレンダリング
        const viewport = page.getViewport({ scale: scale, rotation: quant });

        const srcCanvas = document.createElement('canvas');
        srcCanvas.width = Math.max(1, Math.round(viewport.width));
        srcCanvas.height = Math.max(1, Math.round(viewport.height));
        const srcCtx = srcCanvas.getContext('2d', { alpha: false });

        srcCtx.fillStyle = '#FFFFFF';
        srcCtx.fillRect(0, 0, srcCanvas.width, srcCanvas.height);

        await page.render({ canvasContext: srcCtx, viewport: viewport }).promise;

        // スケール計算
        const scaleX = srcCanvas.width / pageW;
        const scaleY = srcCanvas.height / pageH;

        const sx = Math.round(llx * scaleX);
        const sy = Math.round((pageH - ury) * scaleY);
        const sw = Math.max(1, Math.round((urx - llx) * scaleX));
        const sh = Math.max(1, Math.round((ury - lly) * scaleY));

        // トリミング領域を切り出し
        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = sw;
        cropCanvas.height = sh;
        const cropCtx = cropCanvas.getContext('2d', { alpha: false });

        cropCtx.fillStyle = '#FFFFFF';
        cropCtx.fillRect(0, 0, sw, sh);

        cropCtx.drawImage(srcCanvas, sx, sy, sw, sh, 0, 0, sw, sh);

        return cropCanvas.toDataURL('image/png');

    } catch (error) {
        console.error('[cropRestrictedPdfPageToImage] error:', error);
        throw error;
    }
};

// ========================================
// 空白ページ作成
// ========================================
window.createBlankPage = async function () {
    try {
        const { PDFDocument } = PDFLib;
        const blankPdf = await PDFDocument.create();
        blankPdf.addPage([595.28, 841.89]);
        const pdfBytes = await blankPdf.save();
        return uint8ArrayToBase64(pdfBytes);
    } catch (error) {
        console.error('Error creating blank page:', error);
        return '';
    }
}

// ========================================
// PDFページ抽出
// ========================================
window.extractPdfPage = async function (pdfData, pageIndex, cacheKey = null) {
    try {
        const { PDFDocument } = PDFLib;
        const uint8Array = toUint8Array(pdfData);

        let srcPdfDoc = null;
        if (cacheKey && window._pdfCache.has(cacheKey)) {
            srcPdfDoc = window._pdfCache.get(cacheKey);
        } else {
            try {
                srcPdfDoc = await PDFDocument.load(uint8Array);
                if (cacheKey) {
                    window._pdfCache.set(cacheKey, srcPdfDoc);
                }
            } catch (loadErr) {
                // 制限付きのPDFの場合，ここで画像化する
                return await imageFallbackPdf(uint8Array, pageIndex, cacheKey);
            }
        }

        const newPdf = await PDFDocument.create();

        try {
            if (cacheKey && window._pdfCache.isRestricted(cacheKey)) {
                throw new Error('file-restricted-precheck');
            }
            const [copiedPage] = await newPdf.copyPages(srcPdfDoc, [pageIndex]);
            newPdf.addPage(copiedPage);
        } catch (copyError) {
            return await imageFallbackPdf(uint8Array, pageIndex, cacheKey);
        }

        const pdfBytes = await newPdf.save();
        return uint8ArrayToBase64(pdfBytes);

    } catch (error) {
        console.error(`Error extracting PDF page ${pageIndex}:`, error);
        return await window.createBlankPage();
    }
};

// ========================================
// ページ抽出してストレージに保存（Base64を返さない）
// ========================================
window.extractPdfPageToStorage = async function (pdfData, pageIndex, fileId) {
    try {
        const { PDFDocument } = PDFLib;
        const uint8Array = toUint8Array(pdfData);

        let srcPdfDoc = null;
        if (fileId && window._pdfCache.has(fileId)) {
            srcPdfDoc = window._pdfCache.get(fileId);
        } else {
            try {
                srcPdfDoc = await PDFDocument.load(uint8Array);
                if (fileId) {
                    window._pdfCache.set(fileId, srcPdfDoc);
                }
            } catch (loadErr) {
                return await extractAndStoreWithFallback(uint8Array, pageIndex, fileId);
            }
        }

        const newPdf = await PDFDocument.create();

        try {
            if (fileId && window._pdfCache.isRestricted(fileId)) {
                throw new Error('file-restricted-precheck');
            }
            const [copiedPage] = await newPdf.copyPages(srcPdfDoc, [pageIndex]);
            newPdf.addPage(copiedPage);
        } catch (copyError) {
            return await extractAndStoreWithFallback(uint8Array, pageIndex, fileId);
        }

        const pdfBytes = await newPdf.save();
        window._pdfPageStorage.set(fileId, pageIndex, pdfBytes);

        return {
            success: true,
            sizeBytes: pdfBytes.byteLength,
            isRestricted: fileId ? window._pdfCache.isRestricted(fileId) : false
        };

    } catch (error) {
        console.error(`Error extracting page to storage:`, error);
        return { success: false, error: error.message };
    }
};

// 制限付きPDF用のフォールバック（ストレージ版）
async function extractAndStoreWithFallback(uint8Array, pageIndex, fileId) {
    if (fileId) {
        window._pdfCache.markRestricted(fileId);
    }

    const pdf = await loadPdfDocument(uint8Array);
    const page = await pdf.getPage(pageIndex + 1);

    const scale = pdfConfig?.pdfSettings?.scales?.unlock || 1.5;
    const canvas = await renderPageToCanvas(page, scale, 0, { fillWhite: true });

    const imgDataUrl = canvas.toDataURL('image/png');
    const imgBytes = base64ToUint8Array(imgDataUrl.split(',')[1]);

    const { PDFDocument } = PDFLib;
    const imgPdf = await PDFDocument.create();
    const embedded = await imgPdf.embedPng(imgBytes);
    imgPdf.addPage([canvas.width, canvas.height]);
    const [imgPage] = imgPdf.getPages();
    imgPage.drawImage(embedded, { x: 0, y: 0, width: canvas.width, height: canvas.height });

    const pdfBytes = await imgPdf.save();
    window._pdfPageStorage.set(fileId, pageIndex, pdfBytes);

    return {
        success: true,
        sizeBytes: pdfBytes.byteLength,
        isRestricted: true
    };
}

// ========================================
// ストレージ管理API
// ========================================

// ストレージからページデータを取得（Base64文字列で返す）
window.getStoredPageData = function (fileId, pageIndex) {
    const uint8Array = window._pdfPageStorage.get(fileId, pageIndex);
    if (!uint8Array) return null;
    return uint8ArrayToBase64(uint8Array);
};

// ストレージにページデータが存在するか確認
window.hasStoredPageData = function (fileId, pageIndex) {
    return window._pdfPageStorage.has(fileId, pageIndex);
};

// ストレージにページデータを設定（編集後の保存用）
window.setStoredPageData = function (fileId, pageIndex, uint8Array) {
    window._pdfPageStorage.set(fileId, pageIndex, uint8Array);
    return { success: true, sizeBytes: uint8Array.byteLength };
};

// ストレージからページデータを削除
window.deleteStoredPageData = function (fileId, pageIndex) {
    return window._pdfPageStorage.delete(fileId, pageIndex);
};

// ファイルの全ページを削除
window.deleteStoredPagesForFile = function (fileId) {
    return window._pdfPageStorage.deleteAllForFile(fileId);
};

// ストレージ統計を取得
window.getPageStorageInfo = function () {
    return window._pdfPageStorage.getStorageInfo();
};

// ストレージクリア
window._clearPageStorage = function () {
    window._pdfPageStorage.clear();
    return window._pdfPageStorage.getStorageInfo();
};

// ========================================
// ストレージベースの結合操作
// ========================================
window.mergePdfPagesFromStorage = async function (pageKeys) {
    const { PDFDocument, degrees } = PDFLib;
    const mergedPdf = await PDFDocument.create();

    for (let i = 0; i < pageKeys.length; i++) {
        const key = pageKeys[i];
        const { fileId, pageIndex, rotateAngle } = key;

        const pageBytes = window._pdfPageStorage.get(fileId, pageIndex);
        if (!pageBytes) {
            console.error(`Page not found in storage: ${fileId}_${pageIndex}`);
            continue;
        }

        try {
            const pdfDoc = await PDFDocument.load(pageBytes);
            const [page] = await mergedPdf.copyPages(pdfDoc, [0]);

            if (rotateAngle && rotateAngle % 360 !== 0) {
                page.setRotation(degrees(rotateAngle));
            }

            mergedPdf.addPage(page);
        } catch (error) {
            console.error(`Error merging page ${i}:`, error);
            throw error;
        }
    }

    const mergedPdfBytes = await mergedPdf.save();
    const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
    return URL.createObjectURL(blob);
};

// ========================================
// プレビュー生成（ストレージから）
// ========================================
window.generatePreviewFromStorage = async function (fileId, pageIndex, rotateAngle, scaleKey) {
    const pageBytes = window._pdfPageStorage.get(fileId, pageIndex);
    if (!pageBytes) {
        console.warn(`[generatePreviewFromStorage] Page not found in storage: fileId=${fileId}, pageIndex=${pageIndex}`);
        throw new Error(`Page not found in storage: ${fileId}_${pageIndex}`);
    }

    const pdfBase64 = uint8ArrayToBase64(pageBytes);
    return await window.generatePreviewImage(pdfBase64, rotateAngle, scaleKey);
};

// ========================================
// 単一PDFページサムネイル生成(EditPage向け)
// ========================================
window.generatePdfThumbnailFromPageData = async function (pdfData) {
    try {
        const uint8Array = base64ToUint8Array(pdfData);
        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(1);
        const canvas = await renderPageToCanvas(page, pdfConfig.pdfSettings.scales.thumbnail);
        return canvas.toDataURL('image/png');
    } catch (error) {
        console.error('Error rendering single PDF page:', error);
        return '';
    }
};

// ========================================
// プレビュー画像生成
// ========================================
window.generatePreviewImage = async function (pdfBase64, rotateAngle, scaleKey = "normal") {
    const uint8Array = base64ToUint8Array(pdfBase64);

    // 埋め込み画像が大きいと制限にかかるため，maxImageSize を明示的に -1 に設定（ない場合は自動で無制限になるが，ここでは明示的にする）
    const pdf = await loadPdfDocument(uint8Array, {
        maxImageSize: -1,
        verbosity: 0
    });
    const page = await pdf.getPage(1);

    const scales = pdfConfig && pdfConfig.pdfSettings && pdfConfig.pdfSettings.scales ? pdfConfig.pdfSettings.scales : null;
    const normal = scales && scales.normal ? scales.normal : 1.0;

    let previewScale;
    if (scales && typeof scales[scaleKey] !== "undefined") {
        previewScale = scales[scaleKey];
    } else if (scales && typeof scales.preview !== "undefined") {
        previewScale = scales.preview;
    } else {
        previewScale = normal;
    }

    const canvas = await renderPageToCanvas(page, previewScale, rotateAngle || 0);
    return canvas.toDataURL('image/jpeg', 0.85);
};

// ========================================
// ファイルサイズ取得
// ========================================
window.getPdfFileSize = async function (url) {
    const response = await fetch(url);
    const blob = await response.blob();
    const sizeMB = (blob.size / (1024 * 1024)).toFixed(2) + "MB";
    return sizeMB;
};

/**
 * PDFページの元サイズ（pt単位）を取得
 */
window.getPdfPageOriginalSize = async function (pdfBase64) {
    try {
        const uint8Array = base64ToUint8Array(pdfBase64);
        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 1.0, rotation: 0 });

        return {
            width: viewport.width,   // pt (1pt ≈ 1.333px at 96dpi)
            height: viewport.height
        };
    } catch (e) {
        console.error('getPdfPageOriginalSize error', e);
        return null;
    }
};

// ========================================
// ダウンロード
// ========================================
window.downloadFileFromUrl = function (url, filename, mimeType) {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.type = mimeType || 'application/octet-stream';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// ========================================
// PDF複数ページレンダリング
// ========================================
window.renderPdfPages = async function (pdfUrl, canvasIds) {
    if (!window.pdfjsLib) {
        console.error("pdfjsLib is not loaded");
        return;
    }

    const pdf = await loadPdfDocument(await fetch(pdfUrl).then(r => r.arrayBuffer()).then(b => new Uint8Array(b)));

    for (let i = 0; i < canvasIds.length; i++) {
        const page = await pdf.getPage(i + 1);
        const canvas = document.getElementById(canvasIds[i]);
        if (!canvas) continue;

        const viewport = page.getViewport({ scale: pdfConfig.pdfSettings.scales.normal });
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const context = canvas.getContext('2d');
        await page.render({ canvasContext: context, viewport: viewport }).promise;
    }
};

// ========================================
// Canvas存在確認
// ========================================
window.checkCanvasExists = function (canvasId) {
    return !!document.getElementById(canvasId);
};

// ========================================
// PDF ロック解除
// ========================================
window.unlockPdf = async function (pdfData, password) {
    const uint8Array = toUint8Array(pdfData);
    const pdf = await loadPdfDocument(uint8Array, { password });

    const { PDFDocument } = PDFLib;
    const unlockedPdf = await PDFDocument.create();

    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const canvas = await renderPageToCanvas(
            page,
            pdfConfig.pdfSettings.scales.unlock,
            0,
            { fillWhite: true }
        );

        const imgData = canvas.toDataURL('image/png');
        const img = await unlockedPdf.embedPng(imgData);
        const pdfPage = unlockedPdf.addPage([canvas.width, canvas.height]);
        pdfPage.drawImage(img, {
            x: 0, y: 0,
            width: canvas.width,
            height: canvas.height
        });
    }

    return uint8ArrayToBase64(await unlockedPdf.save());
};

// ========================================
// PDF編集（テキスト・画像追加）
// ========================================
window.editPdfPageWithElements = async function (pdfBase64, editJson) {
    const { PDFDocument, rgb, StandardFonts, degrees } = PDFLib;

    if (!PDFLib._fontkitRegistered) {
        if (window.fontkit) {
            PDFLib.PDFDocument.prototype.registerFontkit(window.fontkit);
            PDFLib._fontkitRegistered = true;
        } else {
            throw new Error("fontkitがロードされていません。");
        }
    }

    const pdfBytes = base64ToUint8Array(pdfBase64);
    const pdfDoc = await PDFDocument.load(pdfBytes);
    const page = pdfDoc.getPage(0);
    const pageHeight = page.getHeight();

    let editElements = [];
    try {
        editElements = JSON.parse(editJson);
    } catch (e) {
        console.error("editJson parse error", e, editJson);
    }

    const fontManager = new PdfFontManager(pdfDoc);

    for (const el of editElements) {
        if (el.Type === 0 || el.Type === "Text") {
            // ...existing text rendering code...
            const font = await fontManager.getFont(el.Text, {
                isBold: el.IsBold,
                isSerif: (el.FontFamily || '').toLowerCase().includes('notoserif')
            });

            const rotateDegrees = degrees(el.Rotation || 0);
            const fontSize = Number(el.FontSize) || 16;
            const specifiedLineHeight = (typeof el.LineHeight !== "undefined" && el.LineHeight > 0) ? Number(el.LineHeight) : null;
            const lineHeightPx = specifiedLineHeight || fontSize;

            const text = el.Text || "";
            const startX = (typeof el.X === "number") ? el.X : 0;
            const maxWidth = (typeof el.Width === "number" && el.Width > 0)
                ? Number(el.Width)
                : (page.getWidth() - startX);

            function splitToLines(paragraph, font, size, maxW) {
                if (!paragraph) return [''];
                const lines = [];
                const tokens = paragraph.split(/(\s+)/);
                let current = '';
                for (const token of tokens) {
                    const tokenWidth = font.widthOfTextAtSize(token, size);
                    const currentWidth = current ? font.widthOfTextAtSize(current, size) : 0;
                    if (currentWidth + tokenWidth <= maxW) {
                        current += token;
                    } else {
                        if (current) {
                            lines.push(current);
                        }
                        if (tokenWidth <= maxW) {
                            current = token;
                        } else {
                            let chunk = '';
                            for (let i = 0; i < token.length; i++) {
                                chunk += token[i];
                                const w = font.widthOfTextAtSize(chunk, size);
                                if (w > maxW) {
                                    if (chunk.length > 1) {
                                        lines.push(chunk.slice(0, -1));
                                        chunk = chunk.slice(-1);
                                    } else {
                                        lines.push(chunk);
                                        chunk = '';
                                    }
                                }
                            }
                            current = chunk;
                        }
                    }
                }
                if (current) lines.push(current);
                return lines;
            }

            const paragraphs = text.split('\n');
            const wrappedLines = [];
            for (const p of paragraphs) {
                const lines = splitToLines(p, font, fontSize, maxWidth);
                if (lines.length === 0) wrappedLines.push('');
                else wrappedLines.push(...lines);
            }

            const startY = pageHeight - (el.Y || 0) - fontSize;
            for (let i = 0; i < wrappedLines.length; i++) {
                page.drawText(wrappedLines[i] || '', {
                    x: startX,
                    y: startY - (i * lineHeightPx),
                    size: fontSize,
                    font: font,
                    color: hexToRgb(el.Color || "#000000"),
                    rotate: rotateDegrees
                });
            }
        } else if (el.Type === 1 || el.Type === "Image") {
            if (el.ImageUrl && (el.ImageUrl.startsWith("data:image/png") || el.ImageUrl.startsWith("data:image/jpeg"))) {
                const rotation = el.Rotation || 0;
                const flipH = el.FlipHorizontal || false;
                const flipV = el.FlipVertical || false;

                // Canvas経由で変換（回転・反転適用）
                const transformResult = await applyImageTransformations(el.ImageUrl, rotation, flipH, flipV);

                const processedBase64 = transformResult.dataUrl.split(',')[1];
                const processedImg = await pdfDoc.embedPng(base64ToUint8Array(processedBase64));

                // 回転後の画像サイズを元の縦横比で pt 単位に変換
                const scaleFromOriginal = el.Width / el.ImageOriginalWidth;

                // 回転後の画像サイズ（ピクセル）を、同じ縮尺で pt 単位に変換
                const drawWidth = transformResult.width * scaleFromOriginal;
                const drawHeight = transformResult.height * scaleFromOriginal;

                // EditPage では画像の左上を基準に X/Y を管理しているが、
                // 回転後は画像の外接矩形が変わるため、中心を維持するように調整

                // 回転前の中心座標（ページ座標）
                const centerX = el.X + el.Width / 2;
                const centerY = el.Y + el.Height / 2;

                // 回転後の左上座標を逆算（中心を維持）
                const adjustedX = centerX - drawWidth / 2;
                const adjustedY = centerY - drawHeight / 2;

                // PDF座標系での配置（左下基点）
                const drawParams = {
                    x: adjustedX,
                    y: pageHeight - adjustedY - drawHeight,
                    width: drawWidth,
                    height: drawHeight
                };
                page.drawImage(processedImg, drawParams);
            } else {
                console.warn("未対応画像形式: ", el.ImageUrl ? el.ImageUrl.substring(0, 30) : "");
            }
        }
    }

    const newPdfBytes = await pdfDoc.save();
    return uint8ArrayToBase64(newPdfBytes);
};


/**
 * Canvas経由で画像の回転・反転を適用
 * @returns {Promise<{dataUrl: string, width: number, height: number}>}
 */
async function applyImageTransformations(imageDataUrl, rotation, flipH, flipV) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            console.log("元画像サイズ:", { width: img.width, height: img.height });

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            // 回転角度を正規化
            const normalizedRotation = ((rotation % 360) + 360) % 360;
            console.log("正規化された回転角度:", normalizedRotation);

            // 回転角度に応じたキャンバスサイズ計算
            let canvasWidth, canvasHeight;

            if (normalizedRotation === 0 || normalizedRotation === 180) {
                canvasWidth = img.width;
                canvasHeight = img.height;
            } else if (normalizedRotation === 90 || normalizedRotation === 270) {
                // 90度・270度：幅と高さを入れ替え
                canvasWidth = img.height;
                canvasHeight = img.width;
            } else {
                // 45度などの中間角度：外接矩形を計算
                const rad = (normalizedRotation * Math.PI) / 180;
                const cos = Math.abs(Math.cos(rad));
                const sin = Math.abs(Math.sin(rad));
                canvasWidth = Math.ceil(img.width * cos + img.height * sin);
                canvasHeight = Math.ceil(img.width * sin + img.height * cos);
            }

            console.log("計算されたキャンバスサイズ:", { canvasWidth, canvasHeight });

            canvas.width = canvasWidth;
            canvas.height = canvasHeight;

            // 透明背景（PNG対応）
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // 変換の中心を設定
            ctx.translate(canvas.width / 2, canvas.height / 2);

            // 回転を適用
            ctx.rotate((normalizedRotation * Math.PI) / 180);

            // 反転を適用
            const scaleX = flipH ? -1 : 1;
            const scaleY = flipV ? -1 : 1;
            ctx.scale(scaleX, scaleY);

            // 画像を描画（中心基点）
            ctx.drawImage(img, -img.width / 2, -img.height / 2, img.width, img.height);

            const result = {
                dataUrl: canvas.toDataURL('image/png'),
                width: canvasWidth,
                height: canvasHeight
            };

            console.log("変換結果:", result);
            resolve(result);
        };
        img.onerror = reject;
        img.src = imageDataUrl;
    });
}



// ========================================
// PDFページサイズ取得
// ========================================
window.getPdfPageSize = async function (pdfBase64) {
    try {
        const uint8Array = base64ToUint8Array(pdfBase64);
        const pdfDoc = await PDFLib.PDFDocument.load(uint8Array);
        const page = pdfDoc.getPage(0);
        const { width, height } = page.getSize();
        return { width, height };
    } catch (error) {
        console.error('Error getting PDF page size:', error);
        // デフォルトでA4サイズを返す
        return { width: 595, height: 842 };
    }
};

// ========================================
// スタンプ追加
// ========================================
window.addStampsToPdf = async function (pdfBytes, stamps) {
    const { PDFDocument, rgb, StandardFonts, degrees } = PDFLib;

    if (!PDFLib._fontkitRegistered) {
        if (window.fontkit) {
            PDFLib.PDFDocument.prototype.registerFontkit(window.fontkit);
            PDFLib._fontkitRegistered = true;
        } else {
            console.warn("fontkitがロードされていません。日本語フォントは使用できません。");
        }
    }

    const rotateAngle = stamps.length > 0 ? (stamps[0].rotateAngle || 0) : 0;
    const normalizedAngle = ((rotateAngle % 360) + 360) % 360;

    const pdfDoc = await PDFDocument.load(pdfBytes);
    const page = pdfDoc.getPage(0);
    const { width, height } = page.getSize();

    function transformCoordinates(corner, offsetX, offsetY, rotateAngle, pageWidth, pageHeight, textWidth, fontSize) {
        let x = 0, y = 0;
        let textRotation = 0;

        const angle = ((rotateAngle % 360) + 360) % 360;

        if (angle === 0) {
            switch (corner) {
                case 'TopLeft':
                    x = offsetX;
                    y = pageHeight - offsetY - fontSize;
                    break;
                case 'Top':
                    x = pageWidth / 2 - textWidth / 2;
                    y = pageHeight - offsetY - fontSize;
                    break;
                case 'TopRight':
                    x = pageWidth - offsetX - textWidth;
                    y = pageHeight - offsetY - fontSize;
                    break;
                case 'BottomLeft':
                    x = offsetX;
                    y = offsetY;
                    break;
                case 'Bottom':
                    x = pageWidth / 2 - textWidth / 2;
                    y = offsetY;
                    break;
                case 'BottomRight':
                    x = pageWidth - offsetX - textWidth;
                    y = offsetY;
                    break;
            }
            textRotation = 0;
        } else if (angle === 90) {
            switch (corner) {
                case 'TopLeft':
                    x = offsetY;
                    y = offsetX;
                    break;
                case 'Top':
                    x = offsetY;
                    y = pageHeight / 2 - textWidth / 2;
                    break;
                case 'TopRight':
                    x = offsetY;
                    y = pageHeight - offsetX - textWidth;
                    break;
                case 'BottomLeft':
                    x = pageWidth - offsetY;
                    y = offsetX;
                    break;
                case 'Bottom':
                    x = pageWidth - offsetY;
                    y = pageHeight / 2 - textWidth / 2;
                    break;
                case 'BottomRight':
                    x = pageWidth - offsetY;
                    y = pageHeight - offsetX - textWidth;
                    break;
            }
            textRotation = 90;
        } else if (angle === 180) {
            switch (corner) {
                case 'TopLeft':
                    x = pageWidth - offsetX;
                    y = offsetY;
                    break;
                case 'Top':
                    x = pageWidth / 2 - textWidth / 2;
                    y = offsetY;
                    break;
                case 'TopRight':
                    x = offsetX + textWidth;
                    y = offsetY;
                    break;
                case 'BottomLeft':
                    x = pageWidth - offsetX;
                    y = pageHeight - offsetY;
                    break;
                case 'Bottom':
                    x = pageWidth / 2 - textWidth / 2;
                    y = pageHeight - offsetY;
                    break;
                case 'BottomRight':
                    x = offsetX + textWidth;
                    y = pageHeight - offsetY;
                    break;
            }
            textRotation = 180;
        } else if (angle === 270) {
            switch (corner) {
                case 'TopLeft':
                    x = pageWidth - offsetY;
                    y = pageHeight - offsetX;
                    break;
                case 'Top':
                    x = pageWidth - offsetY;
                    y = pageHeight / 2 - textWidth / 2;
                    break;
                case 'TopRight':
                    x = pageWidth - offsetY;
                    y = offsetX + textWidth;
                    break;
                case 'BottomLeft':
                    x = offsetY;
                    y = pageHeight - offsetX;
                    break;
                case 'Bottom':
                    x = offsetY;
                    y = pageHeight / 2 - textWidth / 2;
                    break;
                case 'BottomRight':
                    x = offsetY;
                    y = offsetX + textWidth;
                    break;
            }
            textRotation = -90;
        }

        return { x, y, textRotation };
    }

    // 全スタンプから必要なフォントを収集
    const fontsToLoad = new Set();
    for (const stamp of stamps) {
        const text = stamp.text || "";
        const fontFamily = stamp.fontFamily || "NotoSansJP";
        const isBold = stamp.isBold || false;

        if (containsJapanese(text)) {
            // 日本語を含む場合は強制的にNotoフォント
            if (fontFamily.includes("Serif")) {
                fontsToLoad.add(isBold ? "NotoSerifJP-Bold" : "NotoSerifJP-Regular");
            } else {
                fontsToLoad.add(isBold ? "NotoSansJP-Bold" : "NotoSansJP-Regular");
            }
        } else {
            // 英数字のみの場合、フォント選択を尊重
            if (fontFamily === "NotoSansJP") {
                fontsToLoad.add(isBold ? "NotoSansJP-Bold" : "NotoSansJP-Regular");
            } else if (fontFamily === "NotoSerifJP") {
                fontsToLoad.add(isBold ? "NotoSerifJP-Bold" : "NotoSerifJP-Regular");
            }
            // システムフォント、Helvetica、TimesRomanは標準フォントを使用するので読み込み不要
        }
    }

    // フォントを読み込んでキャッシュ
    const fontCache = {};
    for (const fontKey of fontsToLoad) {
        try {
            const fontUrl = `/fonts/${fontKey}.ttf`;
            const fontBytes = await fetch(fontUrl).then(res => res.arrayBuffer());
            fontCache[fontKey] = await pdfDoc.embedFont(fontBytes, { subset: false });
        } catch (fontError) {
            console.warn(`フォント読み込み失敗: ${fontKey}`, fontError);
        }
    }

    for (const stamp of stamps) {

        let text = stamp.text || "";
        if (!text) {
            console.warn("Empty text, skipping stamp");
            continue;
        }


        const fontFamily = stamp.fontFamily || "NotoSansJP";
        const isBold = stamp.isBold || false;
        let font;
        if (containsJapanese(text)) {
            // 日本語を含む場合、NotoフォントのSans/Serifを使い分け
            let fontKey;
            if (fontFamily.includes("Serif")) {
                fontKey = isBold ? "NotoSerifJP-Bold" : "NotoSerifJP-Regular";
            } else {
                fontKey = isBold ? "NotoSansJP-Bold" : "NotoSansJP-Regular";
            }

            font = fontCache[fontKey];
            if (!font) {
                console.error("日本語フォントが読み込まれていません");
                font = await pdfDoc.embedFont(StandardFonts.Helvetica);
            }
        } else {
            // 英数字のみの場合
            if (fontFamily === "NotoSansJP") {
                const fontKey = isBold ? "NotoSansJP-Bold" : "NotoSansJP-Regular";
                font = fontCache[fontKey] || await pdfDoc.embedFont(isBold ? StandardFonts.HelveticaBold : StandardFonts.Helvetica);
            } else if (fontFamily === "NotoSerifJP") {
                const fontKey = isBold ? "NotoSerifJP-Bold" : "NotoSerifJP-Regular";
                font = fontCache[fontKey] || await pdfDoc.embedFont(isBold ? StandardFonts.TimesRomanBold : StandardFonts.TimesRoman);
            } else if (fontFamily === "Helvetica") {
                font = await pdfDoc.embedFont(isBold ? StandardFonts.HelveticaBold : StandardFonts.Helvetica);
            } else if (fontFamily === "TimesRoman") {
                font = await pdfDoc.embedFont(isBold ? StandardFonts.TimesRomanBold : StandardFonts.TimesRoman);
            } else if (fontFamily === "monospace") {
                font = await pdfDoc.embedFont(isBold ? StandardFonts.CourierBold : StandardFonts.Courier);
            } else if (fontFamily === "serif") {
                font = await pdfDoc.embedFont(isBold ? StandardFonts.TimesRomanBold : StandardFonts.TimesRoman);
            } else {
                // sans-serif or その他
                font = await pdfDoc.embedFont(isBold ? StandardFonts.HelveticaBold : StandardFonts.Helvetica);
            }
        }

        const fontSize = stamp.fontSize || 12;
        const textWidth = font.widthOfTextAtSize(text, fontSize);
        // フォントの descender を考慮した補正
        // NotoSansJP の場合、フォントサイズの約 20% が descender
        const descenderRatio = 0.2;
        const offsetYAdjustment = fontSize * descenderRatio;

        const transformed = transformCoordinates(
            stamp.corner,
            stamp.offsetX,
            stamp.offsetY + offsetYAdjustment,
            normalizedAngle,
            width,
            height,
            textWidth,
            fontSize
        );

        const color = stamp.color ?
            rgb(stamp.color.r || 0, stamp.color.g || 0, stamp.color.b || 0) :
            rgb(0, 0, 0);

        try {
            page.drawText(text, {
                x: transformed.x,
                y: transformed.y,
                size: fontSize,
                font: font,
                color: color,
                rotate: degrees(transformed.textRotation),
            });
        } catch (drawError) {
            console.error("スタンプ描画エラー:", drawError);
            throw drawError;
        }
    }

    // 最適化オプションでPDFを保存
    const savedBytes = await pdfDoc.save({
        useObjectStreams: true,  // オブジェクトストリームを使用して圧縮
    });
    return savedBytes;
};

// ========================================
// トリミング（ラスタ化版）
// ========================================
window.cropPdfPageRasterized = async function (pdfBase64, normX, normY, normWidth, normHeight, rotateAngle = 0) {
    try {
        const uint8Array = base64ToUint8Array(pdfBase64);
        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(1);

        const originalViewport = page.getViewport({ scale: 1.0, rotation: 0 });
        const pageW = originalViewport.width;
        const pageH = originalViewport.height;

        const quant = normalizeRotationAngle(rotateAngle);
        const scale = pdfConfig?.pdfSettings?.scales?.unlock || 1.5;

        const nx = Math.max(0, Math.min(1, Number(normX) || 0));
        const ny = Math.max(0, Math.min(1, Number(normY) || 0));
        const nw = Math.max(0, Math.min(1, Number(normWidth) || 0));
        const nh = Math.max(0, Math.min(1, Number(normHeight) || 0));

        const llx = nx * pageW;
        const lly = pageH * (1 - ny - nh);
        const urx = llx + (nw * pageW);
        const ury = lly + (nh * pageH);

        const viewport = page.getViewport({ scale: scale, rotation: quant });

        const srcCanvas = document.createElement('canvas');
        srcCanvas.width = Math.max(1, Math.round(viewport.width));
        srcCanvas.height = Math.max(1, Math.round(viewport.height));
        const srcCtx = srcCanvas.getContext('2d', { alpha: false });
        await page.render({ canvasContext: srcCtx, viewport: viewport }).promise;

        const scaleX = srcCanvas.width / pageW;
        const scaleY = srcCanvas.height / pageH;

        const sx = Math.round(llx * scaleX);
        const sy = Math.round((pageH - ury) * scaleY);
        const sw = Math.max(1, Math.round((urx - llx) * scaleX));
        const sh = Math.max(1, Math.round((ury - lly) * scaleY));

        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = sw;
        cropCanvas.height = sh;
        const cropCtx = cropCanvas.getContext('2d', { alpha: false });
        cropCtx.drawImage(srcCanvas, sx, sy, sw, sh, 0, 0, sw, sh);

        const imgDataUrl = cropCanvas.toDataURL('image/png');
        const imgBase64 = imgDataUrl.split(',')[1];
        const imgBytes = base64ToUint8Array(imgBase64);

        const { PDFDocument } = PDFLib;
        const doc = await PDFDocument.create();
        const png = await doc.embedPng(imgBytes);
        const newPage = doc.addPage([sw, sh]);
        newPage.drawImage(png, { x: 0, y: 0, width: sw, height: sh });

        const newPdfBytes = await doc.save();
        return uint8ArrayToBase64(newPdfBytes);
    } catch (e) {
        console.error('[cropPdfPageRasterized] Error:', e);
        return pdfBase64 || "";
    }
};

// ========================================
// トリミング（ベクトル版）
// ========================================
window.cropPdfPageToTrimVector = async function (pdfBase64, normX, normY, normWidth, normHeight, rotateAngle = 0) {
    try {
        const bytes = base64ToUint8Array(pdfBase64);
        const { PDFDocument, PDFName } = PDFLib;

        const srcDoc = await PDFDocument.load(bytes);
        const srcPage = srcDoc.getPages()[0];
        const pageW = srcPage.getWidth();
        const pageH = srcPage.getHeight();

        const nx = Math.max(0, Math.min(1, Number(normX) || 0));
        const ny = Math.max(0, Math.min(1, Number(normY) || 0));
        const nw = Math.max(0, Math.min(1, Number(normWidth) || 0));
        const nh = Math.max(0, Math.min(1, Number(normHeight) || 0));

        const quant = normalizeRotationAngle(rotateAngle);

        let llx, lly, urx, ury;

        if (quant === 0) {
            // 回転なし
            llx = nx * pageW;
            lly = pageH * (1 - ny - nh);
            urx = llx + (nw * pageW);
            ury = lly + (nh * pageH);

        } else if (quant === 90 || quant === 270) {
            // 90度・270度回転時の座標変換
            const displayW = pageH;  // 回転後の横幅
            const displayH = pageW;  // 回転後の縦幅
            
            const sx = nx * displayW;  // 表示X座標
            const sy = ny * displayH;  // 表示Y座標
            const sw = nw * displayW;  // 表示幅
            const sh = nh * displayH;  // 表示高さ

            if (quant === 90) {
                // 90度時計回り
                llx = displayH - sy - sh;
                lly = sx;
                urx = displayH - sy;
                ury = sx + sw;
            } else {
                // 270度反時計回り
                // 表示の左上 (0,0) → 元PDFの右上 (pageW, pageH)
                // 表示X (→) → 元PDF Y (↓)
                // 表示Y (↓) → 元PDF X (←)
                
                llx = displayH - sy - sh;  // 表示Y → 元PDF X（右から左へ、反転）
                lly = displayW - sx - sw;  // 表示X → 元PDF Y（下から上へ、反転）
                urx = displayH - sy;       // 表示Y+高さ → 元PDF X
                ury = displayW - sx;       // 表示X+幅 → 元PDF Y
            }

        } else if (quant === 180) {
            // 180度回転
            llx = pageW * (1 - nx - nw);
            lly = pageH * ny;
            urx = pageW * (1 - nx);
            ury = pageH * (ny + nh);
        }

        const clampedLlX = Math.max(0, Math.min(pageW, Math.round(llx)));
        const clampedLlY = Math.max(0, Math.min(pageH, Math.round(lly)));
        const clampedUrX = Math.max(0, Math.min(pageW, Math.round(urx)));
        const clampedUrY = Math.max(0, Math.min(pageH, Math.round(ury)));

        const outDoc = await PDFDocument.create();
        const [copied] = await outDoc.copyPages(srcDoc, [0]);
        outDoc.addPage(copied);

        copied.node.set(PDFName.of('CropBox'), outDoc.context.obj([
            clampedLlX,
            clampedLlY,
            clampedUrX,
            clampedUrY
        ]));

        const outBytes = await outDoc.save();
        return uint8ArrayToBase64(outBytes);
    } catch (e) {
        console.error('[cropPdfPageToTrimVector] Error:', e);
        return pdfBase64 || "";
    }
};

// ========================================
// トリミング操作（ストレージベース）
// ========================================

// ベクタートリミング（ストレージから）
window.cropPdfPageVectorFromStorage = async function (fileId, pageIndex, normX, normY, normWidth, normHeight, rotateAngle = 0) {
    const pageBytes = window._pdfPageStorage.get(fileId, pageIndex);
    if (!pageBytes) {
        throw new Error(`Page not found in storage: ${fileId}_${pageIndex}`);
    }

    const pdfBase64 = uint8ArrayToBase64(pageBytes);
    return await window.cropPdfPageToTrimVector(pdfBase64, normX, normY, normWidth, normHeight, rotateAngle);
};

// ラスタライズトリミング（ストレージから）
window.cropPdfPageRasterizedFromStorage = async function (fileId, pageIndex, normX, normY, normWidth, normHeight, rotateAngle = 0) {
    const pageBytes = window._pdfPageStorage.get(fileId, pageIndex);
    if (!pageBytes) {
        throw new Error(`Page not found in storage: ${fileId}_${pageIndex}`);
    }

    const pdfBase64 = uint8ArrayToBase64(pageBytes);
    return await window.cropPdfPageRasterized(pdfBase64, normX, normY, normWidth, normHeight, rotateAngle);
};

// ========================================
// 画像サイズ取得
// ========================================
window.getImageSizeFromDataUrl = function (dataUrl) {
    return new Promise((resolve) => {
        try {
            if (!dataUrl) { resolve([0, 0]); return; }
            const img = new Image();
            img.onload = function () {
                resolve([img.naturalWidth || 0, img.naturalHeight || 0]);
            };
            img.onerror = function () {
                resolve([0, 0]);
            };
            img.src = dataUrl;
            setTimeout(() => {
                if (!img.complete) resolve([0, 0]);
            }, 2000);
        } catch (e) {
            resolve([0, 0]);
        }
    });
};

// 画像トリミング（ストレージから）
window.cropPdfPageToImageFromStorage = async function (fileId, pageIndex, normX, normY, normWidth, normHeight, rotateAngle = 0, dpi = 150) {
    const pageBytes = window._pdfPageStorage.get(fileId, pageIndex);
    if (!pageBytes) {
        throw new Error(`Page not found in storage: ${fileId}_${pageIndex}`);
    }

    const pdfBase64 = uint8ArrayToBase64(pageBytes);
    return await window.cropPdfPageToImage(pdfBase64, normX, normY, normWidth, normHeight, rotateAngle, dpi);
};

// ========================================
// トリミング → 画像出力
// ========================================
window.cropPdfPageToImage = async function (pageDataBase64, normX, normY, normWidth, normHeight, rotateAngle = 0, dpi = 150) {
    try {
        const uint8Array = base64ToUint8Array(pageDataBase64);
        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(1);

        const originalViewport = page.getViewport({ scale: 1.0, rotation: 0 });
        const pageW = originalViewport.width;
        const pageH = originalViewport.height;

        const quant = normalizeRotationAngle(rotateAngle);
        const scale = dpi / 72;

        const nx = Math.max(0, Math.min(1, Number(normX) || 0));
        const ny = Math.max(0, Math.min(1, Number(normY) || 0));
        const nw = Math.max(0, Math.min(1, Number(normWidth) || 0));
        const nh = Math.max(0, Math.min(1, Number(normHeight) || 0));

        // cropPdfPageRasterized と同じ座標計算
        const llx = nx * pageW;
        const lly = pageH * (1 - ny - nh);
        const urx = llx + (nw * pageW);
        const ury = lly + (nh * pageH);

        const viewport = page.getViewport({ scale: scale, rotation: quant });

        const srcCanvas = document.createElement('canvas');
        srcCanvas.width = Math.max(1, Math.round(viewport.width));
        srcCanvas.height = Math.max(1, Math.round(viewport.height));
        const srcCtx = srcCanvas.getContext('2d', { alpha: false });

        srcCtx.fillStyle = '#FFFFFF';
        srcCtx.fillRect(0, 0, srcCanvas.width, srcCanvas.height);

        await page.render({ canvasContext: srcCtx, viewport: viewport }).promise;

        // cropPdfPageRasterized と同じスケール計算
        const scaleX = srcCanvas.width / pageW;
        const scaleY = srcCanvas.height / pageH;

        const sx = Math.round(llx * scaleX);
        const sy = Math.round((pageH - ury) * scaleY);
        const sw = Math.max(1, Math.round((urx - llx) * scaleX));
        const sh = Math.max(1, Math.round((ury - lly) * scaleY));

        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = sw;
        cropCanvas.height = sh;
        const cropCtx = cropCanvas.getContext('2d', { alpha: false });

        cropCtx.fillStyle = '#FFFFFF';
        cropCtx.fillRect(0, 0, sw, sh);

        cropCtx.drawImage(srcCanvas, sx, sy, sw, sh, 0, 0, sw, sh);

        return cropCanvas.toDataURL('image/png');

    } catch (error) {
        console.error('[cropPdfPageToImage] error:', error);
        throw error;
    }
};

/**
 * Nアップ PDF 生成（元ページサイズに基づく出力サイズ計算）
 */
window.createNUpPdf = async function (pages, nup, direction, orientation, showDividers = false) {
    try {
        const { PDFDocument, rgb, degrees, PDFName } = PDFLib;

        const pagePdfs = [];

        for (let i = 0; i < pages.length; i++) {
            const pageData = pages[i];

            try {
                const pdfBytes = base64ToUint8Array(pageData.pageData);

                const tempPdf = await PDFDocument.load(pdfBytes);
                const tempPage = tempPdf.getPage(0);

                const { width, height } = tempPage.getSize();

                // Contents ストリームの存在確認
                const pageDict = tempPage.node;
                const contents = pageDict.lookup(PDFName.of('Contents'));

                if (!contents) {
                    console.warn(`[createNUpPdf] Page ${i + 1} has no Contents, creating blank page`);
                    const blankPdf = await PDFDocument.create();
                    const blankPage = blankPdf.addPage([width, height]);
                    blankPage.drawRectangle({
                        x: 0, y: 0, width, height,
                        color: rgb(1, 1, 1),
                        opacity: 1
                    });
                    pagePdfs.push({
                        pdf: blankPdf,
                        rotateAngle: pageData.rotateAngle || 0,
                        isBlank: true
                    });
                } else {
                    pagePdfs.push({
                        pdf: tempPdf,
                        rotateAngle: pageData.rotateAngle || 0,
                        isBlank: false
                    });
                }
            } catch (error) {
                console.error(`[createNUpPdf] Error loading page ${i + 1}:`, error);
                pagePdfs.push(null);
            }
        }

        const { rows, cols } = getNUpGrid(nup, orientation);

        const validPages = pagePdfs.filter(p => p !== null);
        if (validPages.length === 0) {
            throw new Error('No valid pages to process');
        }

        let totalWidth = 0, totalHeight = 0;
        validPages.forEach(item => {
            const page = item.pdf.getPage(0);
            const { width, height } = page.getSize();
            totalWidth += width;
            totalHeight += height;
        });

        const avgWidth = totalWidth / validPages.length;
        const avgHeight = totalHeight / validPages.length;
        const pageWidth = avgWidth * cols;
        const pageHeight = avgHeight * rows;
        const cellWidth = pageWidth / cols;
        const cellHeight = pageHeight / rows;

        const orderedIndices = getPageOrder(pagePdfs.length, rows, cols, direction);

        const outputPdf = await PDFDocument.create();
        const outputPage = outputPdf.addPage([pageWidth, pageHeight]);

        outputPage.drawRectangle({
            x: 0, y: 0,
            width: pageWidth, height: pageHeight,
            color: rgb(1, 1, 1)
        });

        for (let i = 0; i < orderedIndices.length; i++) {
            const pageIndex = orderedIndices[i];
            if (pageIndex >= pagePdfs.length || pagePdfs[pageIndex] === null) {
                console.warn(`[createNUpPdf] Skipping invalid page at index ${pageIndex}`);
                continue;
            }

            const item = pagePdfs[pageIndex];

            try {
                const [embeddedPage] = await outputPdf.embedPdf(item.pdf, [0]);
                const { width, height } = embeddedPage;

                const { x, y } = getCellPosition(i, rows, cols, cellWidth, cellHeight, direction);

                const rotateAngle = item.rotateAngle || 0;
                const normalizedAngle = ((rotateAngle % 360) + 360) % 360;
                const isRotated = (normalizedAngle === 90 || normalizedAngle === 270);

                // 回転後の実効サイズ（セル内に収めるための計算用）
                const effectiveWidth = isRotated ? height : width;
                const effectiveHeight = isRotated ? width : height;

                // セル内に収まるスケールを計算
                const scaleX = cellWidth / effectiveWidth;
                const scaleY = cellHeight / effectiveHeight;
                const scale = Math.min(scaleX, scaleY);

                // 実際の描画サイズ（回転前の元サイズ × scale）
                const drawWidth = width * scale;
                const drawHeight = height * scale;

                // セル内での中央寄せオフセット（回転後のサイズで計算）
                const rotatedDrawWidth = isRotated ? drawHeight : drawWidth;
                const rotatedDrawHeight = isRotated ? drawWidth : drawHeight;

                const offsetX = (cellWidth - rotatedDrawWidth) / 2;
                const offsetY = (cellHeight - rotatedDrawHeight) / 2;

                // 回転の基点調整（PDFLib は左下基点で回転）
                let finalX = x + offsetX;
                let finalY = y + offsetY;

                if (normalizedAngle === 90) {
                    // 90度回転時の正しい配置
                    // 回転後にセル中央に来るよう、回転前の左下位置を計算
                    finalX = x + offsetX + rotatedDrawWidth;  // 回転後の幅分だけ右に移動
                    finalY = y + offsetY;                      // Y座標はそのまま
                } else if (normalizedAngle === 180) {
                    // 180度回転
                    finalX = x + offsetX + drawWidth;
                    finalY = y + offsetY + drawHeight;
                } else if (normalizedAngle === 270) {
                    // 270度回転
                    finalX = x + offsetX;
                    finalY = y + offsetY + rotatedDrawHeight;
                }

                outputPage.drawPage(embeddedPage, {
                    x: finalX,
                    y: finalY,
                    width: drawWidth,    // 元のサイズ × scale
                    height: drawHeight,  // 元のサイズ × scale
                    rotate: degrees(normalizedAngle)
                });

            } catch (embedError) {
                console.error(`[createNUpPdf] Error embedding page ${pageIndex + 1}:`, embedError);
                console.error(`  - Stack:`, embedError.stack);
                throw embedError;
            }
        }

        if (showDividers) {
            for (let c = 1; c < cols; c++) {
                const lineX = c * cellWidth;
                outputPage.drawLine({
                    start: { x: lineX, y: 0 },
                    end: { x: lineX, y: pageHeight },
                    thickness: 1,
                    color: rgb(0.7, 0.7, 0.7),
                    opacity: 0.5
                });
            }
            for (let r = 1; r < rows; r++) {
                const lineY = r * cellHeight;
                outputPage.drawLine({
                    start: { x: 0, y: lineY },
                    end: { x: pageWidth, y: lineY },
                    thickness: 1,
                    color: rgb(0.7, 0.7, 0.7),
                    opacity: 0.5
                });
            }
        }

        const pdfBytes = await outputPdf.save();
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);

        return url;

    } catch (error) {
        console.error('[createNUpPdf] Fatal error:', error);
        console.error('[createNUpPdf] Stack trace:', error.stack);
        throw error;
    }
};

/**
 * Nアップのグリッド（行×列）を取得（orientation対応）
 */
function getNUpGrid(nup, orientation) {
    const isLandscape = orientation === 'landscape';

    switch (nup) {
        case 2:
            return isLandscape ? { rows: 1, cols: 2 } : { rows: 2, cols: 1 };
        case 4:
            return { rows: 2, cols: 2 };
        case 8:
            return isLandscape ? { rows: 2, cols: 4 } : { rows: 4, cols: 2 };
        case 16:
            return { rows: 4, cols: 4 };
        default:
            return { rows: 2, cols: 1 };
    }
}

/**
 * 並び方向に応じたページ順序を取得
 */
function getPageOrder(pageCount, rows, cols, direction) {
    const indices = [];

    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            let index;

            switch (direction) {
                case 'forward':
                    // 左→右、上→下
                    index = row * cols + col;
                    break;

                case 'forward-vertical':
                    // 上→下、左→右（列優先）
                    index = col * rows + row;
                    break;

                case 'reverse-horizontal':
                    // 右→左、上→下
                    index = row * cols + (cols - 1 - col);
                    break;

                case 'reverse-vertical':
                    // 右の列から上→下
                    index = (cols - 1 - col) * rows + row;
                    break;

                case 'reverse':
                    // 右→左、下→上
                    index = (rows - 1 - row) * cols + (cols - 1 - col);
                    break;

                default:
                    index = row * cols + col;
            }

            if (index < pageCount) {
                indices.push(index);
            }
        }
    }

    return indices;
}

/**
 * セルの座標を取得（PDF座標系：左下原点）
 */
function getCellPosition(index, rows, cols, cellWidth, cellHeight, direction) {
    let row, col;

    switch (direction) {
        case 'forward':
            row = Math.floor(index / cols);
            col = index % cols;
            break;

        case 'forward-vertical':
            col = Math.floor(index / rows);
            row = index % rows;
            break;

        case 'reverse-horizontal':
            row = Math.floor(index / cols);
            col = cols - 1 - (index % cols);
            break;

        case 'reverse-vertical':
            col = cols - 1 - Math.floor(index / rows);
            row = index % rows;
            break;

        case 'reverse':
            row = rows - 1 - Math.floor(index / cols);
            col = cols - 1 - (index % cols);
            break;

        default:
            row = Math.floor(index / cols);
            col = index % cols;
    }

    // PDF座標系（左下原点）での位置
    const x = col * cellWidth;
    const y = (rows - 1 - row) * cellHeight;

    return { x, y };
}

/**
 * PDFページをタイル分割（ラスタ化オプション対応）
 */
window.splitPdfPageIntoTiles = async function (pageData, tileCount, direction, rasterize = false) {
    try {
        const { PDFDocument } = PDFLib;
        const uint8Array = base64ToUint8Array(pageData);
        const srcPdf = await PDFDocument.load(uint8Array);
        const srcPage = srcPdf.getPage(0);
        const { width, height } = srcPage.getSize();

        // グリッド計算
        const { rows, cols } = getTileGrid(tileCount, direction);
        const tileWidth = width / cols;
        const tileHeight = height / rows;

        const results = [];

        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const x = col * tileWidth;
                const y = height - (row + 1) * tileHeight; // PDF座標系

                let tileUrl;
                if (rasterize) {
                    // ラスタ化：指定領域を画像として抽出してPDF化
                    tileUrl = await createRasterizedTile(uint8Array, x, y, tileWidth, tileHeight, width, height);
                } else {
                    // ベクトル：CropBox でトリミング
                    tileUrl = await createVectorTile(srcPdf, x, y, tileWidth, tileHeight);
                }

                if (tileUrl) {
                    results.push(tileUrl);
                }
            }
        }

        return results;
    } catch (error) {
        console.error('splitPdfPageIntoTiles error:', error);
        throw error;
    }
};

/**
 * タイルのグリッド（行×列）を取得
 */
function getTileGrid(tileCount, direction) {
    const isHorizontal = direction === 'horizontal';

    switch (tileCount) {
        case 2:
            return isHorizontal ? { rows: 2, cols: 1 } : { rows: 1, cols: 2 };
        case 4:
            return { rows: 2, cols: 2 };
        case 8:
            return isHorizontal ? { rows: 4, cols: 2 } : { rows: 2, cols: 4 };
        case 16:
            return { rows: 4, cols: 4 };
        default:
            return { rows: 2, cols: 2 };
    }
}

/**
 * ベクトルタイル生成（CropBox使用）
 */
async function createVectorTile(srcPdf, x, y, w, h) {
    try {
        const { PDFDocument, PDFName } = PDFLib;
        const outputPdf = await PDFDocument.create();
        const [copiedPage] = await outputPdf.copyPages(srcPdf, [0]);
        outputPdf.addPage(copiedPage);

        // CropBox を設定
        copiedPage.node.set(PDFName.of('CropBox'), outputPdf.context.obj([
            Math.round(x),
            Math.round(y),
            Math.round(x + w),
            Math.round(y + h)
        ]));

        const pdfBytes = await outputPdf.save();
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        return URL.createObjectURL(blob);
    } catch (error) {
        console.error('createVectorTile error:', error);
        return null;
    }
}

/**
 * ラスタ化タイル生成（画像化）
 */
async function createRasterizedTile(uint8Array, x, y, w, h, pageWidth, pageHeight) {
    try {
        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(1);

        const scale = 2.0; // 高解像度
        const viewport = page.getViewport({ scale, rotation: 0 });

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(viewport.width));
        canvas.height = Math.max(1, Math.round(viewport.height));

        const ctx = canvas.getContext('2d', { alpha: false });
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        await page.render({ canvasContext: ctx, viewport }).promise;

        // PDF座標をCanvas座標に変換
        const scaleX = canvas.width / pageWidth;
        const scaleY = canvas.height / pageHeight;

        const sx = Math.round(x * scaleX);
        const sy = Math.round((pageHeight - y - h) * scaleY); // Y座標反転
        const sw = Math.max(1, Math.round(w * scaleX));
        const sh = Math.max(1, Math.round(h * scaleY));

        // 指定領域を切り出し
        const tileCanvas = document.createElement('canvas');
        tileCanvas.width = sw;
        tileCanvas.height = sh;
        const tileCtx = tileCanvas.getContext('2d', { alpha: false });
        tileCtx.drawImage(canvas, sx, sy, sw, sh, 0, 0, sw, sh);

        // PNG → PDF 化
        const imgDataUrl = tileCanvas.toDataURL('image/png');
        const imgBytes = base64ToUint8Array(imgDataUrl.split(',')[1]);

        const { PDFDocument } = PDFLib;
        const tilePdf = await PDFDocument.create();
        const pngImage = await tilePdf.embedPng(imgBytes);
        const tilePage = tilePdf.addPage([sw, sh]);
        tilePage.drawImage(pngImage, { x: 0, y: 0, width: sw, height: sh });

        const pdfBytes = await tilePdf.save();
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        return URL.createObjectURL(blob);
    } catch (error) {
        console.error('createRasterizedTile error:', error);
        return null;
    }
}

/**
 * Canvas の自然なサイズを取得
 */
window.getCanvasNaturalSize = function (canvasId) {
    try {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return [0, 0];

        // Canvas の実際のピクセルサイズ
        return [canvas.width, canvas.height];
    } catch (e) {
        console.error('getCanvasNaturalSize error', e);
        return [0, 0];
    }
};

window.setCanvasSize = function (canvasId, width, height) {
    try {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return false;

        canvas.naturalWidth = width;
        canvas.naturalHeight = height;
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';

        return true;
    } catch (e) {
        console.error('setCanvasSize error', e);
        return false;
    }
};

async function canvasToBlobAsync(canvas, type = 'image/jpeg', quality = 0.8) {
    return await new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}

async function canvasToBlobUrl(canvas, type = 'image/jpeg', quality = 0.8) {
    const blob = await canvasToBlobAsync(canvas, type, quality);
    if (!blob) throw new Error('toBlob returned null');
    return URL.createObjectURL(blob);
}

window.revokeObjectUrl = function (url) {
    try {
        if (url && typeof url === 'string' && url.startsWith('blob:')) {
            URL.revokeObjectURL(url);
            return true;
        }
    } catch (e) {
        console.error('revokeObjectUrl error', e);
    }
    return false;
}

window.fetchBlobAsBytes = async function (blobUrl) {
    try {
        const response = await fetch(blobUrl);
        const arrayBuffer = await response.arrayBuffer();
        return new Uint8Array(arrayBuffer);
    } catch (error) {
        console.error('fetchBlobAsBytes error:', error);
        throw error;
    }
};

/**
 * PDF の Blob URL からサムネイル Blob URL を生成
 */
window.generatePdfThumbnailUrl = async function (pdfBlobUrl) {
    try {
        const response = await fetch(pdfBlobUrl);
        const arrayBuffer = await response.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);

        const pdf = await loadPdfDocument(uint8Array);
        const page = await pdf.getPage(1);
        const canvas = await renderPageToCanvas(page, pdfConfig.pdfSettings.scales.thumbnail, 0);

        return await canvasToBlobUrl(canvas, 'image/jpeg', 0.8);
    } catch (error) {
        console.error('generatePdfThumbnailUrl error:', error);
        return "";
    }
};

