let renderTask = null;

window.getDevicePixelRatio = function() {
    return window.devicePixelRatio || 1;
};

window.getPageSourceInfo = async function (fileId, pageIndex, pageData) {
    try {
        if (!pageData) return null;
        // base64 の中身を取り出す（data:...;base64, を想定）
        let raw = pageData;
        const m = /^data:.*;base64,(.*)$/.exec(pageData);
        if (m && m[1]) raw = m[1];

        const dpr = window.getDevicePixelRatio();

        // try PDF
        try {
            const bytes = Uint8Array.from(atob(raw), c => c.charCodeAt(0));
            const pdf = await window.pdfjsLib.getDocument({
                data: bytes,
                standardFontDataUrl: pdfjsLib.GlobalWorkerOptions.standardFontDataUrl,
                wasmUrl: pdfjsLib.GlobalWorkerOptions.wasmUrl,
                openjpegJsUrl: pdfjsLib.GlobalWorkerOptions.openjpegJsUrl
            }).promise;
            try {
                const page = await pdf.getPage(1);
                const baseViewport = page.getViewport({ scale: 1.0 });
                return { origW: baseViewport.width, origH: baseViewport.height, dpr: dpr };
            } finally {
                if (pdf && typeof pdf.destroy === 'function') {
                    try { pdf.destroy(); } catch (e) { console.warn('pdf.destroy() error', e); }
                }
            }
        } catch (pdfErr) {
            // not PDF -> try image
            try {
                const dataUrl = pageData;
                const img = await new Promise((res, rej) => {
                    const i = new Image();
                    i.onload = () => res(i);
                    i.onerror = rej;
                    i.src = dataUrl;
                });
                return { origW: img.naturalWidth, origH: img.naturalHeight, dpr: dpr };
            } catch (imgErr) {
                console.error("getPageSourceInfo: not pdf nor image", imgErr);
                return null;
            }
        }
    } catch (err) {
        console.error("getPageSourceInfo error", err);
        return null;
    }
};

window.drawPdfPageToCanvas = async function (id, pageData, zoomLevel = 1.0, rotateAngle) {
    try {
        const canvasSelector = `#pdf-canvas-${id}`;
        const canvas = document.querySelector(canvasSelector);
        if (!canvas || !pageData) return;

        // pageData base64
        let rawBase64 = pageData;
        const m = /^data:.*;base64,(.*)$/.exec(pageData);
        if (m && m[1]) rawBase64 = m[1];

        let bytes;
        try { bytes = Uint8Array.from(atob(rawBase64), c => c.charCodeAt(0)); } catch (e) { console.error("drawPdfPageToCanvas: invalid base64", e); return; }

        const pdfjsLib = window.pdfjsLib;
        if (!pdfjsLib) { console.error("pdfjsLib not loaded"); return; }

        if (window._pdfRenderTask && window._pdfRenderTask.cancel) { try { window._pdfRenderTask.cancel(); } catch { } }

        const loadingTask = pdfjsLib.getDocument({
            data: bytes,
            cMapUrl: pdfjsLib.GlobalWorkerOptions.cMapUrl,
            cMapPacked: pdfjsLib.GlobalWorkerOptions.cMapPacked,
            standardFontDataUrl: pdfjsLib.GlobalWorkerOptions.standardFontDataUrl,
            wasmUrl: pdfjsLib.GlobalWorkerOptions.wasmUrl,
            openjpegJsUrl: pdfjsLib.GlobalWorkerOptions.openjpegJsUrl
        });
        const pdf = await loadingTask.promise;
        try {
            const page = await pdf.getPage(1);

            // 回転・ズームを反映したviewport
            const dpr = window.getDevicePixelRatio();
            const effectiveDpr = zoomLevel < 1 ? 1 : dpr;
            const targetScale = zoomLevel * effectiveDpr;
            const viewport = page.getViewport({ scale: targetScale, rotation: rotateAngle });

            canvas.width = Math.round(viewport.width);
            canvas.height = Math.round(viewport.height);
            // オフスクリーンcanvasでPDFを描画
            const off = document.createElement('canvas');
            off.width = Math.max(1, Math.round(viewport.width));
            off.height = Math.max(1, Math.round(viewport.height));
            const offCtx = off.getContext('2d');
            if (offCtx && offCtx.setTransform) offCtx.setTransform(1, 0, 0, 1, 0, 0);

            window._pdfRenderTask = page.render({ canvasContext: offCtx, viewport: viewport });
            await window._pdfRenderTask.promise;

            // メインcanvasに転送
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // 中央に配置
            const dx = Math.round((canvas.width - off.width) / 2);
            const dy = Math.round((canvas.height - off.height) / 2);
            ctx.drawImage(off, 0, 0, off.width, off.height, dx, dy, off.width, off.height);

            // CSSズーム用のtransform（必要なら）
            if (ctx.setTransform) ctx.setTransform(effectiveDpr, 0, 0, effectiveDpr, 0, 0);
        } finally {
            if (pdf && typeof pdf.destroy === 'function') {
                try { pdf.destroy(); } catch (e) { console.warn('pdf.destroy() error', e); }
            }
        }
    } catch (err) {
        if (err && err.name === "RenderingCancelledException") return;
        console.error("drawPdfPageToCanvas error", err);
    }
};

// window.getTagNameFromEvent = function (e) {
//     // e.target.tagName を返す
//     return e && e.target && e.target.tagName ? e.target.tagName : "";
// };

window.getCanvasCoords = function (canvasSelector, clientX, clientY, zoomLevel) {
    const canvas = document.querySelector(canvasSelector);
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const x = (clientX - rect.left) / zoomLevel;
    const y = (clientY - rect.top) / zoomLevel;
    return { x, y };
};

window.triggerFileInput = (element) => {
    element.click();
};
window.clearFileInput = function (element) {
    if (element) element.value = "";
};

// window.registerGlobalMouseUp = function (dotNetHelper) {
//     window._blazorMouseUpHandler = function (e) {
//         dotNetHelper.invokeMethodAsync('OnGlobalMouseUp');
//     };
//     window.addEventListener('mouseup', window._blazorMouseUpHandler);
// };
// window.unregisterGlobalMouseUp = function () {
//     if (window._blazorMouseUpHandler) {
//         window.removeEventListener('mouseup', window._blazorMouseUpHandler);
//         window._blazorMouseUpHandler = null;
//     }
// };

// window.registerGlobalMouseMove = function (dotNetRef) {
//     window._globalMouseMoveHandler = function (e) {
//         dotNetRef.invokeMethodAsync('OnGlobalMouseMove', {
//             clientX: e.clientX,
//             clientY: e.clientY
//         });
//     };
//     window.addEventListener('mousemove', window._globalMouseMoveHandler);
// };
// window.unregisterGlobalMouseMove = function () {
//     if (window._globalMouseMoveHandler) {
//         window.removeEventListener('mousemove', window._globalMouseMoveHandler);
//         window._globalMouseMoveHandler = null;
//     }
// };

window.getElementRect = function (selector) {
    const el = document.querySelector(selector);
    if (!el) return { left: 0, top: 0, width: 0, height: 0 };
    const r = el.getBoundingClientRect();
    return { left: r.left, top: r.top, width: r.width, height: r.height };
};

window.getViewportSize = function () {
    return {
        width: window.innerWidth,
        height: window.innerHeight
    };
};

/**
 * edit-canvas-containerのサイズを計算して固定
 * ヘッダーとサイドバーを除いた画面領域のサイズに固定する
 */
window.updateEditContainerSize = function() {
    const container = document.getElementById('edit-canvas-container');
    if (!container) return { width: 0, height: 0 };
    
    const rect = container.getBoundingClientRect();
    return { 
        width: Math.max(1, rect.width), 
        height: Math.max(1, rect.height) 
    };
};

/**
 * EditPage用ウィンドウリサイズハンドラ
 */
// window.registerEditPageResize = function(dotNetRef) {
//     if (!dotNetRef) return;
    
//     window._editPageResize = window._editPageResize || {};
//     window._editPageResize.dotNetRef = dotNetRef;
    
//     let resizeTimer = null;
//     const onResize = function() {
//         if (resizeTimer) clearTimeout(resizeTimer);
//         resizeTimer = setTimeout(() => {
//             try {
//                 // コンテナサイズを更新
//                 const size = window.updateEditContainerSize();
                
//                 // .NET側に通知
//                 if (window._editPageResize.dotNetRef && window._editPageResize.dotNetRef.invokeMethodAsync) {
//                     window._editPageResize.dotNetRef.invokeMethodAsync('OnWindowResized', size.width, size.height).catch(() => {});
//                 }
//             } catch (e) {
//                 console.error('EditPage resize error', e);
//             }
//         }, 150);
//     };
    
//     window._editPageResize.handler = onResize;
//     window.addEventListener('resize', onResize, { passive: true });
    
//     // 初回実行
//     try {
//         window.updateEditContainerSize();
//     } catch (e) {}
// };

// window.unregisterEditPageResize = function() {
//     if (window._editPageResize && window._editPageResize.handler) {
//         window.removeEventListener('resize', window._editPageResize.handler);
//         window._editPageResize.handler = null;
//         window._editPageResize.dotNetRef = null;
//     }
// };

window.waitForNextFrame = function () {
    return new Promise(resolve => requestAnimationFrame(resolve));
};

window.measureMaxLineWidth = function (text, fontSize, fontFamily) {
    const canvas = window._measureTextCanvas || (window._measureTextCanvas = document.createElement("canvas"));
    const ctx = canvas.getContext("2d");
    ctx.font = `${fontSize}px ${fontFamily}`;
    const lines = text.split('\n');
    let maxWidth = 0;
    for (const line of lines) {
        const w = ctx.measureText(line).width;
        if (w > maxWidth) maxWidth = w;
    }
    return maxWidth;
};

window.selectAllTextarea = function (ref) {
    if (!ref) return;
    ref.select();
};

window.autoResizeTextarea = function (ref) {
    try {
        const resolveEl = (r) => {
            if (!r) return null;
            if (typeof r === "string") return document.getElementById(r);
            if (r instanceof HTMLElement) return r;
            return r;
        };
        const el = resolveEl(ref);
        if (!el || !el.style) {
            console.debug("autoResizeTextarea: element not found:", ref);
            return 0;
        }

        return new Promise((resolve) => {
            requestAnimationFrame(() => {
                try {
                    // 高さを一旦リセット（重要：削除時に縮小するため）
                    el.style.height = "1px"; // ← "auto" より確実
                    void el.getBoundingClientRect(); // 強制リフロー
                    
                    const cs = window.getComputedStyle(el);
                    const fontSize = parseFloat(cs.fontSize) || 16;
                    const lineHeight = parseFloat(cs.lineHeight) || fontSize * 1.2;
                    
                    // scrollHeight で実際の高さを取得
                    const scrollH = el.scrollHeight;
                    
                    // 行数を計算（削除時も正確に計算）
                    const lines = Math.max(1, Math.ceil(scrollH / lineHeight));
                    const textareaH = lines * lineHeight;
                    
                    // 高さを設定
                    el.style.height = textareaH + "px";
                    el.style.overflow = "hidden";

                    console.log(`autoResizeTextarea: scrollH=${scrollH}, lines=${lines}, textareaH=${textareaH}`); // ← デバッグ用
                    resolve(textareaH); // border を含めない
                } catch (err) {
                    console.error("autoResizeTextarea inner error", err);
                    resolve(0);
                }
            });
        });
    } catch (err) {
        console.error("autoResizeTextarea error", err);
        return 0;
    }
};

// 画像のBase64からサイズ取得
window.getImageSizeFromBase64 = function (base64) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = function () {
            resolve({ width: img.width, height: img.height });
        };
        img.src = base64;
    });
};

/**
 * EditPage用のマウスムーブハンドラを登録
 * リサイズ/ドラッグ中のみBlazor側に通知
 */
window.registerEditPageMouseHandlers = function(dotNetRef) {
    if (!dotNetRef) return;
    
    window._editPageMouse = window._editPageMouse || {};
    window._editPageMouse.dotNetRef = dotNetRef;
    window._editPageMouse.isActive = false; // リサイズ/ドラッグ中フラグ
    
    let lastMoveTime = 0;
    const throttleMs = 16; // 60FPS
    
    const onMouseMove = function(e) {
        // リサイズ/ドラッグ中でなければ何もしない
        if (!window._editPageMouse.isActive) return;
        
        // スロットル処理
        const now = Date.now();
        if (now - lastMoveTime < throttleMs) return;
        lastMoveTime = now;
        
        // Blazor側に通知
        if (window._editPageMouse.dotNetRef && window._editPageMouse.dotNetRef.invokeMethodAsync) {
            // console.log(`onMouseMove: clientX=${e.clientX}, clientY=${e.clientY}`);
            window._editPageMouse.dotNetRef.invokeMethodAsync('OnMouseMove', {
                clientX: e.clientX,
                clientY: e.clientY
            }).catch(() => {});
        }
    };
    
    const onMouseUp = function(e) {
        window._editPageMouse.isActive = false;
        
        if (window._editPageMouse.dotNetRef && window._editPageMouse.dotNetRef.invokeMethodAsync) {
            window._editPageMouse.dotNetRef.invokeMethodAsync('OnMouseUp').catch(() => {});
        }
    };
    
    window._editPageMouse.moveHandler = onMouseMove;
    window._editPageMouse.upHandler = onMouseUp;
    
    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mouseup', onMouseUp);
};

/**
 * リサイズ/ドラッグ開始を通知
 */
window.setEditPageMouseActive = function(active) {
    if (window._editPageMouse) {
        window._editPageMouse.isActive = !!active;
    }
};

window.unregisterEditPageMouseHandlers = function() {
    if (window._editPageMouse) {
        if (window._editPageMouse.moveHandler) {
            window.removeEventListener('mousemove', window._editPageMouse.moveHandler);
        }
        if (window._editPageMouse.upHandler) {
            window.removeEventListener('mouseup', window._editPageMouse.upHandler);
        }
        window._editPageMouse = null;
    }
};

// キーボードイベントハンドラの登録
window.registerEditPageKeyHandler = function(dotNetRef) {
    if (!dotNetRef) return;
    
    window._editPageKey = window._editPageKey || {};
    window._editPageKey.dotNetRef = dotNetRef;
    
    const onKeyDown = function(e) {
        // input, textarea, select 要素内でのキー入力は無視
        const tagName = (e.target && e.target.tagName) ? e.target.tagName.toUpperCase() : '';
        if (tagName === 'INPUT' || tagName === 'TEXTAREA' || tagName === 'SELECT') {
            return;
        }
        
        // Delete または Backspace キー
        if (e.key === 'Delete' || e.key === 'Backspace') {
            e.preventDefault(); // ブラウザの戻る動作を防止
            if (window._editPageKey.dotNetRef && window._editPageKey.dotNetRef.invokeMethodAsync) {
                window._editPageKey.dotNetRef.invokeMethodAsync('OnKeyDown', e.key).catch(() => {});
            }
        }
    };
    
    window._editPageKey.keyDownHandler = onKeyDown;
    document.addEventListener('keydown', onKeyDown);
};

window.unregisterEditPageKeyHandler = function() {
    if (window._editPageKey && window._editPageKey.keyDownHandler) {
        document.removeEventListener('keydown', window._editPageKey.keyDownHandler);
        window._editPageKey = null;
    }
};