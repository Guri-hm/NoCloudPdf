// ========================================
// QRコード処理ユーティリティ
// カメラには html5-qrcode、画像には jsQR を使用
// ========================================

let html5QrcodeLibLoaded = false;
let html5QrcodeLibLoading = false;
let html5QrcodeLoadPromise = null;

/**
 * html5-qrcode ライブラリを動的にロード
 */
window.loadHtml5QrcodeLibrary = async function() {
    if (html5QrcodeLibLoaded) {
        return true;
    }

    if (html5QrcodeLibLoading) {
        return html5QrcodeLoadPromise;
    }

    html5QrcodeLibLoading = true;
    html5QrcodeLoadPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js';
        script.onload = () => {
            html5QrcodeLibLoaded = true;
            html5QrcodeLibLoading = false;
            resolve(true);
        };
        script.onerror = () => {
            html5QrcodeLibLoading = false;
            console.error('❌ Failed to load html5-qrcode library');
            reject(new Error('Failed to load html5-qrcode library'));
        };
        document.head.appendChild(script);
    });

    return html5QrcodeLoadPromise;
};

// ========================================
// 1. 画像からQRコード読み取り
// ========================================

let jsQrLoadPromise = null;

window.loadJsQrLibrary = function() {
    if (typeof window.jsQR === 'function') {
        return Promise.resolve();
    }
    if (jsQrLoadPromise) {
        return jsQrLoadPromise;
    }

    jsQrLoadPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js';
        script.onload = () => {
            if (typeof window.jsQR !== 'function') {
                script.remove();
                jsQrLoadPromise = null;
                reject(new Error('jsQR is not available'));
                return;
            }
            resolve();
        };
        script.onerror = () => {
            script.remove();
            jsQrLoadPromise = null;
            reject(new Error('Failed to load jsQR library'));
        };
        document.head.appendChild(script);
    });
    return jsQrLoadPromise;
};

async function decodeWithJsQr(file) {
    await window.loadJsQrLibrary();
    const url = URL.createObjectURL(file);
    try {
        const img = await new Promise((resolve, reject) => {
            const i = new Image();
            i.onload = () => resolve(i);
            i.onerror = reject;
            i.src = url;
        });
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) {
            throw new Error('Could not create canvas context');
        }
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = window.jsQR(data.data, data.width, data.height, { inversionAttempts: 'attemptBoth' });
        if (!code || !code.data) {
            throw new Error('jsQR could not detect the code');
        }
        return code.data;
    } finally {
        URL.revokeObjectURL(url);
    }
}

/**
 * 画像ファイル（Base64 or File object）からQRコードをデコード
 * @param {string|File} imageSource - Base64文字列 or File object
 * @returns {Promise<string>} デコードされたテキスト
 */
window.decodeQrCodeFromImage = async function(imageSource) {
    try {
        let file = imageSource;
        if (typeof imageSource === 'string') {
            const response = await fetch(imageSource);
            if (!response.ok) {
                throw new Error(`Failed to load image: ${response.status}`);
            }
            file = await response.blob();
        }

        if (!(file instanceof Blob)) {
            throw new TypeError('Image source must be a URL or Blob');
        }

        return await decodeWithJsQr(file);
    } catch (error) {
        console.error('QR decode error:', error);
        throw new Error('QRコードが見つかりませんでした。画像が鮮明でQRコードが含まれているか確認してください。');
    }
};

/**
 * 画像ファイルから複数のQRコードを検出（可能な場合）
 */
window.decodeMultipleQrCodesFromImage = async function(imageSource) {
    try {
        const result = await window.decodeQrCodeFromImage(imageSource);
        return [result]; // 単一結果を配列として返す
    } catch (error) {
        console.error('Multiple QR decode error:', error);
        return [];
    }
};

// ========================================
// 2. PDFページ（画像化済み）からQRコード読み取り
// ========================================

/**
 * Canvas要素からQRコードを検出
 * @param {string} canvasId - Canvas要素のID
 * @returns {Promise<{success: boolean, text?: string, error?: string}>}
 */
window.scanQrCodeFromCanvas = async function(canvasId) {
    try {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            throw new Error(`Canvas not found: ${canvasId}`);
        }

        // CanvasをBlob経由でスキャン
        const dataUrl = canvas.toDataURL('image/png');
        const text = await window.decodeQrCodeFromImage(dataUrl);

        return {
            success: true,
            text: text
        };
    } catch (error) {
        return {
            success: false,
            error: error.message || 'QR code not found'
        };
    }
};

/**
 * 画像URL（Blob URL or Data URL）からQRコードを検出
 */
window.scanQrCodeFromImageUrl = async function(imageUrl) {
    try {
        // 画像をロードしてCanvasに描画
        const img = new Image();
        img.crossOrigin = 'anonymous';
        
        await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            img.src = imageUrl;
        });

        const canvas = document.createElement('canvas');
        // 小さいサムネイルの場合、一定以上に拡大してからスキャンすると検出率が上がる
        const minDetectWidth = 800;
        let drawWidth = img.naturalWidth || minDetectWidth;
        let drawHeight = img.naturalHeight || minDetectWidth;

        if (drawWidth < minDetectWidth) {
            const scale = minDetectWidth / drawWidth;
            drawWidth = Math.min(1600, Math.round(drawWidth * scale));
            drawHeight = Math.round(drawHeight * scale);
        }

        canvas.width = drawWidth;
        canvas.height = drawHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, drawWidth, drawHeight);

        const dataUrl = canvas.toDataURL('image/png');
        const text = await window.decodeQrCodeFromImage(dataUrl);

        return {
            success: true,
            text: text
        };
    } catch (error) {
        return {
            success: false,
            error: error.message || 'QR code not found'
        };
    }
};

// ========================================
// 3. カメラスキャナー
// ========================================

let activeScanner = null;
let currentCameraId = null;
let resizeObserver = null;
let resizeTimeout = null;
let dotNetReference = null;

/**
 * 利用可能なカメラデバイス一覧を取得
 * @returns {Promise<Array<{id: string, label: string}>>}
 */
window.getQrScannerCameras = async function() {
    try {
        await window.loadHtml5QrcodeLibrary();

        const devices = await Html5Qrcode.getCameras();
        return devices.map(device => ({
            id: device.id,
            label: device.label || `Camera ${device.id}`
        }));
    } catch (error) {
        console.error('Failed to get cameras:', error);
        return [];
    }
};

/**
 * 背面カメラを優先的に取得
 */
window.getPreferredCamera = async function() {
    try {
        const cameras = await window.getQrScannerCameras();
        if (cameras.length === 0) {
            return null;
        }

        // 背面カメラを探す（environment, back, rearなどのキーワード）
        const backCamera = cameras.find(cam => 
            cam.label.toLowerCase().includes('back') ||
            cam.label.toLowerCase().includes('rear') ||
            cam.label.toLowerCase().includes('environment')
        );

        return backCamera || cameras[0];
    } catch (error) {
        console.error('Failed to get preferred camera:', error);
        return null;
    }
};

/**
 * QRコードスキャナーを開始
 * @param {string} elementId - スキャナーを表示する要素のID
 * @param {string} cameraId - 使用するカメラID（nullの場合は優先カメラ）
 * @param {function} onScanSuccess - スキャン成功時のコールバック
 * @returns {Promise<string>} 使用中のカメラID
 */
window.startQrScanner = async function(elementId, cameraId = null, dotNetRef = null) {
    try {
        await window.loadHtml5QrcodeLibrary();

        // 既存のスキャナーを停止
        if (activeScanner) {
            await window.stopQrScanner();
        }

        const element = document.getElementById(elementId);
        if (!element) {
            throw new Error(`Element not found: ${elementId}`);
        }

        // カメラIDが指定されていない場合は優先カメラを取得
        if (!cameraId) {
            const preferredCamera = await window.getPreferredCamera();
            if (!preferredCamera) {
                throw new Error('No camera available');
            }
            cameraId = preferredCamera.id;
        }

        activeScanner = new Html5Qrcode(elementId);
        currentCameraId = cameraId;
        dotNetReference = dotNetRef;

        const config = {
            fps: 10,
            // QRコード検出領域をレスポンシブに設定
            qrbox: function(viewfinderWidth, viewfinderHeight) {
                // ビューポートの小さい方の辺を基準に、70%のサイズを使用
                const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
                const qrboxSize = Math.floor(minEdge * 0.7);
                
                // 最小サイズと最大サイズを設定
                const minSize = 200;  // 最小200px
                const maxSize = 400;  // 最大400px
                const finalSize = Math.max(minSize, Math.min(maxSize, qrboxSize));
                
                console.log(`QR Box size: ${finalSize}px (viewport: ${viewfinderWidth}x${viewfinderHeight})`);
                
                return {
                    width: finalSize,
                    height: finalSize
                };
            },
            aspectRatio: 1.0,  // 1:1 アスペクト比
            // QRコードの文字コード自動検出を有効化
            formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE],
            experimentalFeatures: {
                useBarCodeDetectorIfSupported: true
            }
        };

        await activeScanner.start(
            cameraId,
            config,
            (decodedText, decodedResult) => {
                // スキャン成功時の処理
                // 文字コードの自動検出を試みる（Shift_JISやUTF-8など）
                let text = decodedText;
                
                // デコード結果にバイト配列がある場合、複数の文字コードで試行
                if (decodedResult && decodedResult.result && decodedResult.result.rawBytes) {
                    try {
                        // まずUTF-8として解釈
                        const decoder = new TextDecoder('utf-8');
                        const utf8Text = decoder.decode(new Uint8Array(decodedResult.result.rawBytes));
                        
                        // 文字化けチェック（�が含まれていたらShift_JISを試行）
                        if (!utf8Text.includes('�')) {
                            text = utf8Text;
                        } else {
                            // Shift_JISで再試行
                            try {
                                const sjisDecoder = new TextDecoder('shift_jis');
                                text = sjisDecoder.decode(new Uint8Array(decodedResult.result.rawBytes));
                            } catch (e) {
                                // Shift_JIS失敗時は元のテキストを使用
                            }
                        }
                    } catch (e) {
                        // デコード失敗時は元のテキストを使用
                    }
                }
                
                if (dotNetRef) {
                    dotNetRef.invokeMethodAsync('OnQrCodeScanned', text);
                }
            },
            (errorMessage) => {
                // エラーは無視（連続スキャン中は頻繁に発生）
            }
        );
        
        // カメラ映像を中央に配置するためのスタイル調整
        setTimeout(() => {
            const videoElement = document.querySelector(`#${elementId} video`);
            if (videoElement) {
                videoElement.style.width = '100%';
                videoElement.style.height = 'auto';
                videoElement.style.maxHeight = '100%';
                videoElement.style.objectFit = 'contain';
            }
        }, 100);
        
        // リサイズ監視を開始
        setupResizeObserver(elementId);
        
        return cameraId;
    } catch (error) {
        console.error('Failed to start QR scanner:', error);
        throw error;
    }
};

/**
 * QRコードスキャナーを停止
 */
window.stopQrScanner = async function() {
    try {
        // リサイズ監視を停止
        if (resizeObserver) {
            window.removeEventListener('resize', resizeObserver);
            resizeObserver = null;
        }
        
        if (resizeTimeout) {
            clearTimeout(resizeTimeout);
            resizeTimeout = null;
        }
        
        if (activeScanner) {
            await activeScanner.stop();
            activeScanner.clear();
            activeScanner = null;
            currentCameraId = null;
            dotNetReference = null;
        }
    } catch (error) {
        console.error('Failed to stop QR scanner:', error);
    }
};

/**
 * カメラを切り替え
 */
window.switchQrScannerCamera = async function(elementId, cameraId, dotNetRef = null) {
    try {
        await window.stopQrScanner();
        return await window.startQrScanner(elementId, cameraId, dotNetRef);
    } catch (error) {
        console.error('Failed to switch camera:', error);
        throw error;
    }
};

/**
 * 現在のカメラIDを取得
 */
window.getCurrentCameraId = function() {
    return currentCameraId;
};

/**
 * リサイズ監視を設定（ウィンドウサイズ変更時にスキャナーを再起動）
 */
function setupResizeObserver(elementId) {
    // 既存の監視を停止
    if (resizeObserver) {
        window.removeEventListener('resize', resizeObserver);
        resizeObserver = null;
    }
    
    let lastWidth = window.innerWidth;
    let lastHeight = window.innerHeight;
    
    // Window resizeイベントを使用してサイズ変更を検知
    resizeObserver = async () => {
        const newWidth = window.innerWidth;
        const newHeight = window.innerHeight;
        
        // サイズが10px以上変わった場合のみ再起動
        const widthDiff = Math.abs(newWidth - lastWidth);
        const heightDiff = Math.abs(newHeight - lastHeight);
        
        if (widthDiff > 10 || heightDiff > 10) {
            console.log(`Window resized: ${lastWidth}x${lastHeight} -> ${newWidth}x${newHeight}`);
            
            // デバウンス処理（連続したリサイズイベントを抑制）
            if (resizeTimeout) {
                clearTimeout(resizeTimeout);
            }
            
            resizeTimeout = setTimeout(async () => {
                lastWidth = newWidth;
                lastHeight = newHeight;
                
                // スキャナーを再起動（qr-shaded-regionも再計算される）
                if (activeScanner && currentCameraId && dotNetReference) {
                    console.log('Restarting scanner due to resize...');
                    try {
                        const savedCameraId = currentCameraId;
                        const savedDotNetRef = dotNetReference;
                        await window.stopQrScanner();
                        await window.startQrScanner(elementId, savedCameraId, savedDotNetRef);
                    } catch (error) {
                        console.error('Failed to restart scanner on resize:', error);
                    }
                }
            }, 500);
        }
    };
    
    window.addEventListener('resize', resizeObserver);
}

/**
 * ズーム機能のサポート状態を取得
 */
window.getQrScannerZoomCapabilities = async function() {
    if (!activeScanner) {
        return { supported: false, min: 1.0, max: 1.0, current: 1.0 };
    }

    try {
        const capabilities = activeScanner.getRunningTrackCapabilities();
        
        if (!capabilities || !capabilities.zoomFeature) {
            return { supported: false, min: 1.0, max: 1.0, current: 1.0 };
        }

        const zoomFeature = capabilities.zoomFeature();
        
        return {
            supported: true,
            min: zoomFeature.min(),
            max: zoomFeature.max(),
            current: zoomFeature.value()
        };
    } catch (error) {
        return { supported: false, min: 1.0, max: 1.0, current: 1.0 };
    }
};

/**
 * ズームを適用
 */
window.applyQrScannerZoom = async function(zoomLevel) {
    if (!activeScanner) {
        throw new Error('Scanner not active');
    }

    try {
        const capabilities = activeScanner.getRunningTrackCapabilities();
        if (capabilities && capabilities.zoomFeature) {
            const zoomFeature = capabilities.zoomFeature();
            await zoomFeature.apply(zoomLevel);
        } else {
            console.warn('Zoom feature not available');
        }
    } catch (error) {
        console.error('Failed to apply zoom:', error);
        throw error;
    }
};

// ========================================
// ピンチイン/アウト機能
// ========================================

let pinchStartDistance = 0;
let pinchStartZoom = 1.0;
let pinchHandlersAttached = false;
let pinchTouchStartHandler = null;
let pinchTouchMoveHandler = null;
let pinchTouchEndHandler = null;

/**
 * ピンチジェスチャーのサポートを初期化
 */
window.initQrScannerPinchZoom = function(elementId, dotNetRef = null) {
    const element = document.getElementById(elementId);
    if (!element) {
        console.error('Element not found for pinch zoom:', elementId);
        return;
    }

    // 既存のイベントリスナーを削除
    if (pinchHandlersAttached) {
        if (pinchTouchStartHandler) element.removeEventListener('touchstart', pinchTouchStartHandler);
        if (pinchTouchMoveHandler) element.removeEventListener('touchmove', pinchTouchMoveHandler);
        if (pinchTouchEndHandler) element.removeEventListener('touchend', pinchTouchEndHandler);
    }

    // タッチイベントハンドラー
    pinchTouchStartHandler = (e) => {
        if (e.touches.length === 2 && activeScanner) {
            pinchStartDistance = getTouchDistance(e.touches[0], e.touches[1]);
            
            try {
                const stream = activeScanner.getRunningTrackCameraCapabilities();
                if (stream && stream.zoomFeature) {
                    pinchStartZoom = stream.zoomFeature().value();
                }
            } catch (error) {
                // ズーム取得失敗時は無視
            }
        }
    };

    pinchTouchMoveHandler = async (e) => {
        if (e.touches.length === 2 && activeScanner && pinchStartDistance > 0) {
            e.preventDefault();
            
            const currentDistance = getTouchDistance(e.touches[0], e.touches[1]);
            const scale = currentDistance / pinchStartDistance;
            
            try {
                const stream = activeScanner.getRunningTrackCameraCapabilities();
                if (stream && stream.zoomFeature) {
                    const minZoom = stream.zoomFeature().min();
                    const maxZoom = stream.zoomFeature().max();
                    let newZoom = pinchStartZoom * scale;
                    newZoom = Math.max(minZoom, Math.min(maxZoom, newZoom));
                    
                    await stream.zoomFeature().apply(newZoom);
                }
            } catch (error) {
                // ズームエラーは無視
            }
        }
    };

    pinchTouchEndHandler = (e) => {
        if (e.touches.length < 2) {
            pinchStartDistance = 0;
        }
    };

    element.addEventListener('touchstart', pinchTouchStartHandler);
    element.addEventListener('touchmove', pinchTouchMoveHandler);
    element.addEventListener('touchend', pinchTouchEndHandler);
    
    pinchHandlersAttached = true;
};

/**
 * 2点間の距離を計算
 */
function getTouchDistance(touch1, touch2) {
    const dx = touch1.clientX - touch2.clientX;
    const dy = touch1.clientY - touch2.clientY;
    return Math.sqrt(dx * dx + dy * dy);
}

// ========================================
// ユーティリティ関数
// ========================================

/**
 * テキストがURLかどうかを判定
 */
window.isUrl = function(text) {
    try {
        new URL(text);
        return true;
    } catch {
        return false;
    }
};

/**
 * クリップボードにコピー
 */
window.copyToClipboard = async function(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (error) {
        console.error('Failed to copy to clipboard:', error);
        return false;
    }
};
